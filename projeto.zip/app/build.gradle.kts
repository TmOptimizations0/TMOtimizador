plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tm.otimizador"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tm.otimizador"
        minSdk = 24
        targetSdk = 34
        versionCode = 8
        versionName = "3.1.0"
    }

    // Assina sempre com a chave fixa do repositório (debug.keystore), sem depender da pasta do usuário.
    // Assim cada versão nova instala por cima da anterior.
    signingConfigs {
        val ks = rootProject.file("debug.keystore")
        if (ks.exists()) {
            getByName("debug") {
                storeFile = ks
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
            println("Assinatura: usando a chave fixa " + ks.absolutePath)
        } else {
            println("Assinatura: debug.keystore não encontrado, usando a chave temporária")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
