package com.tm.otimizador

/** Onde o ajuste mora no Android. */
enum class Kind { SETTINGS, DEVCONFIG, PROP }

/**
 * Um valor que o app muda.
 * ns: global/system/secure (SETTINGS) ou o namespace do device_config. Vazio para PROP.
 * on: valor quando a função está ativada.
 * offDefault: valor padrão do Android, usado só se o app não tiver guardado o valor anterior.
 *             null significa apagar a chave (voltar ao padrão do sistema).
 */
data class Target(
    val kind: Kind,
    val ns: String,
    val key: String,
    val on: String,
    val offDefault: String? = null
)

/**
 * Uma função com chave de ativar/desativar.
 * cat: aba onde aparece. sec: seção dentro da aba. icon: símbolo do cartão.
 * short: frase curta do cartão. desc: explicação completa (botão "i").
 * minSdk: versão mínima do Android (API) para a função existir.
 * group: funções do mesmo grupo não ficam ligadas juntas.
 * inBulk: entra em "Ativar pacote seguro".
 * care: true se vale ler o aviso antes de ligar (mostra "Cuidado" no cartão).
 * unavailable: motivo (texto) pelo qual a função não serve neste aparelho; null se serve.
 */
data class Opt(
    val id: String,
    val title: String,
    val short: String,
    val desc: String,
    val targets: List<Target>,
    val cat: String,
    val sec: String,
    val icon: String,
    val minSdk: Int = 24,
    val group: String? = null,
    val inBulk: Boolean = false,
    val unavailable: String? = null,
    val care: Boolean = false
)

/** Perfil de um toque: lista de funções que ele liga. */
data class Profile(
    val name: String,
    val icon: String,
    val badge: String,
    val note: String,
    val ids: List<String>,
    val freeMemory: Boolean
)

/** Cor do app. accent é a cor principal; o resto do tema é calculado a partir dela. */
data class Palette(val name: String, val accent: Long)

val PALETTES = listOf(
    Palette("Azul", 0xFF22D3EE),
    Palette("Azul Royal", 0xFF3B82F6),
    Palette("Verde", 0xFF34D399),
    Palette("Lima", 0xFFA3E635),
    Palette("Amarelo", 0xFFFACC15),
    Palette("Laranja", 0xFFFB923C),
    Palette("Vermelho", 0xFFF87171),
    Palette("Rosa", 0xFFF472B6),
    Palette("Roxo", 0xFFA78BFA)
)

object Sh {
    fun read(t: Target): String = when (t.kind) {
        Kind.SETTINGS -> "settings get ${t.ns} ${t.key}"
        Kind.DEVCONFIG -> "device_config get ${t.ns} ${t.key}"
        Kind.PROP -> "getprop ${t.key}"
    }

    fun write(t: Target, v: String): String = when (t.kind) {
        Kind.SETTINGS -> "settings put ${t.ns} ${t.key} $v"
        Kind.DEVCONFIG -> "device_config put ${t.ns} ${t.key} $v"
        Kind.PROP -> "setprop ${t.key} $v"
    }

    fun clear(t: Target): String = when (t.kind) {
        Kind.SETTINGS -> "settings delete ${t.ns} ${t.key}"
        Kind.DEVCONFIG -> "device_config delete ${t.ns} ${t.key}"
        Kind.PROP -> "setprop ${t.key} ''"
    }

    /** Compara texto ou número ("90" é igual a "90.0"). */
    fun same(a: String, b: String): Boolean {
        if (a == b) return true
        val x = a.toDoubleOrNull()
        val y = b.toDoubleOrNull()
        return x != null && y != null && x == y
    }
}

/** Abas na ordem em que aparecem (nome e símbolo). Início, Perfis, Jogos e Ferramentas não têm chaves. */
val TABS = listOf(
    "Início" to "🏠",
    "Perfis" to "🎯",
    "Desempenho" to "⚡",
    "Tela" to "🖥",
    "Toque" to "👆",
    "Internet" to "🌐",
    "Sistema" to "⚙️",
    "Jogos" to "🎮",
    "Ferramentas" to "🧰"
)

/**
 * Perfis de um toque. Cada um liga só as funções da sua lista e desfaz as do perfil anterior.
 * Funções que o aparelho não suporta são puladas.
 */
val PROFILES = listOf(
    Profile(
        "Performance", "🚀", "Mais desempenho",
        "Foco em velocidade para jogos e apps pesados: libera memória, tela no máximo de Hz, animações rápidas e gráficos mais leves. Gasta mais bateria.",
        listOf("phantom", "freezer", "cached", "hzfixed", "anim", "hwui", "skiagl", "scan", "longpress"),
        true
    ),
    Profile(
        "Bateria", "🔋", "Mais autonomia",
        "Foco em gastar menos: tela em 60Hz, economia de bateria, tela apaga em 30 s, sem varredura de redes e sem avisos de Wi-Fi. O celular fica mais contido.",
        listOf("hz60", "lowpower", "timeout", "scan", "freezer", "haptic", "wifinotif", "notiflight"),
        false
    ),
    Profile(
        "Seguro", "🛡", "Sem risco",
        "Só ajustes comuns do Android, simples e que você desfaz num toque: animações rápidas, sem varredura de redes, sem bolhas e sem avisos desnecessários.",
        listOf("anim", "scan", "wifinotif", "chargesound", "bubbles", "notiflight"),
        false
    ),
    Profile(
        "Equilibrado", "⚖️", "Desempenho e bateria",
        "Meio-termo para o dia a dia: tela adaptativa, processos fantasma liberados, congelar apps, animações rápidas e economia no tempo de tela.",
        listOf("phantom", "freezer", "anim", "hzadapt", "hwui", "scan", "timeout", "wifinotif"),
        false
    )
)

fun target(kind: Kind, ns: String, key: String, on: String, off: String? = null) = Target(kind, ns, key, on, off)

/**
 * Lista de funções para ESTE aparelho.
 * maxHz: maior taxa de atualização que a tela suporta (60 se só tiver 60Hz).
 * brand: fabricante em minúsculas (xiaomi, samsung...), usado só para chaves de marca.
 */
fun buildOpts(maxHz: Int, brand: String): List<Opt> {
    val xiaomi = brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")
    val fast = maxHz > 60
    val noFast = if (fast) null else "Sua tela só tem 60Hz"
    fun hzTargets(min: Int, peak: Int): List<Target> {
        val l = ArrayList<Target>()
        l.add(target(Kind.SETTINGS, "system", "min_refresh_rate", "$min.0"))
        l.add(target(Kind.SETTINGS, "system", "peak_refresh_rate", "$peak.0"))
        // Xiaomi, Redmi e POCO usam também esta chave
        if (xiaomi) l.add(target(Kind.SETTINGS, "system", "user_refresh_rate", peak.toString()))
        return l
    }
    val all = listOf(
    // ---------------------------------------------------------------- Desempenho
    Opt(
        id = "phantom",
        title = "Sem Corte Fantasma",
        short = "Apps pesados não são mortos",
        desc = "O Android 12+ mata processos auxiliares dos apps, o que pode fechar jogos e apps pesados. Isto tira esse limite. Requer Android 12+.",
        targets = listOf(
            target(Kind.DEVCONFIG, "activity_manager", "max_phantom_processes", "2147483647"),
            target(Kind.SETTINGS, "global", "settings_enable_monitor_phantom_procs", "false")
        ),
        cat = "Desempenho", sec = "Memória e processos", icon = "👻",
        minSdk = 31, inBulk = true
    ),
    Opt(
        id = "freezer",
        title = "Congelar Apps",
        short = "Congela apps minimizados",
        desc = "Liga o congelador de apps minimizados do próprio Android (Android 11+). Em alguns aparelhos só vale depois de reiniciar.",
        targets = listOf(target(Kind.SETTINGS, "global", "cached_apps_freezer", "enabled", "device_default")),
        cat = "Desempenho", sec = "Memória e processos", icon = "❄️",
        minSdk = 30, inBulk = true
    ),
    Opt(
        id = "cached",
        title = "Limite de Cache",
        short = "Máximo de 24 apps em cache",
        desc = "Limita quantos apps fechados o Android mantém na memória. Pode liberar RAM, mas reabre apps do zero mais vezes. O Android pode reverter depois de um tempo. Requer Android 10+.",
        targets = listOf(target(Kind.DEVCONFIG, "activity_manager", "max_cached_processes", "24")),
        cat = "Desempenho", sec = "Memória e processos", icon = "🧠",
        minSdk = 29
    ),

    Opt(
        id = "hwui",
        title = "Gráficos Otimizados",
        short = "Desenho de tela mais enxuto",
        desc = "Liga atualizações parciais e pula quadros vazios no motor gráfico do Android (HWUI). Pode deixar a rolagem mais leve em aparelhos fracos. Vale para apps abertos depois e volta ao padrão quando o aparelho reinicia.",
        targets = listOf(
            target(Kind.PROP, "", "debug.hwui.use_partial_updates", "1"),
            target(Kind.PROP, "", "debug.hwui.skip_empty_damage", "1")
        ),
        cat = "Desempenho", sec = "Gráficos", icon = "🎨",
        minSdk = 29
    ),
    Opt(
        id = "skiagl",
        title = "Renderizador Skia GL",
        short = "Gráficos via OpenGL",
        desc = "Força os apps a desenharem com Skia sobre OpenGL. É o mais compatível. Não liga junto com o Vulkan. Vale para apps abertos depois e volta ao padrão quando o aparelho reinicia.",
        targets = listOf(target(Kind.PROP, "", "debug.hwui.renderer", "skiagl")),
        cat = "Desempenho", sec = "Gráficos", icon = "🖼",
        minSdk = 29, group = "gpu"
    ),
    Opt(
        id = "skiavk",
        title = "Renderizador Vulkan",
        short = "Gráficos via Vulkan",
        desc = "Força os apps a desenharem com Skia sobre Vulkan. Pode ajudar em chips novos, mas em GPUs fracas ou antigas causa falhas na imagem. Se der problema, desative. Não liga junto com o Skia GL. Vale para apps abertos depois e volta ao padrão quando o aparelho reinicia.",
        targets = listOf(target(Kind.PROP, "", "debug.hwui.renderer", "skiavk")),
        cat = "Desempenho", sec = "Gráficos", icon = "🌋",
        minSdk = 29, group = "gpu"
    ),

    // ---------------------------------------------------------------- Tela
    Opt(
        id = "hz60",
        title = "Tela em 60Hz",
        short = "Economiza bateria",
        desc = "Trava a tela em 60Hz para gastar menos bateria. Não liga junto com as outras opções de taxa de atualização.",
        targets = hzTargets(60, 60),
        cat = "Tela", sec = "Taxa de atualização", icon = "🔋",
        group = "hz", unavailable = noFast
    ),
    Opt(
        id = "hzfixed",
        title = "Tela em ${maxHz}Hz",
        short = "Tela travada no máximo",
        desc = "Trava a taxa de atualização no máximo da sua tela (${maxHz}Hz). Gasta mais bateria. Algumas marcas ignoram este ajuste; confira o valor real em Início, no cartão TELA.",
        targets = hzTargets(maxHz, maxHz),
        cat = "Tela", sec = "Taxa de atualização", icon = "📺",
        group = "hz", unavailable = noFast
    ),
    Opt(
        id = "hzadapt",
        title = "Tela Adaptativa",
        short = "Alterna entre 60 e ${maxHz}Hz",
        desc = "Sobe até ${maxHz}Hz quando precisa e desce para 60Hz quando a tela está parada. Não liga junto com as outras opções de taxa de atualização. Algumas marcas ignoram este ajuste.",
        targets = hzTargets(60, maxHz),
        cat = "Tela", sec = "Taxa de atualização", icon = "🔄",
        group = "hz", unavailable = noFast
    ),
    Opt(
        id = "anim",
        title = "Animações Rápidas",
        short = "Transições em 0.5x",
        desc = "Deixa as transições do sistema mais ágeis. Não liga junto com Sem Animações. Desativar volta ao valor que estava antes.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "window_animation_scale", "0.5", "1.0"),
            target(Kind.SETTINGS, "global", "transition_animation_scale", "0.5", "1.0"),
            target(Kind.SETTINGS, "global", "animator_duration_scale", "0.5", "1.0")
        ),
        cat = "Tela", sec = "Animações", icon = "🎬",
        group = "anim", inBulk = true
    ),
    Opt(
        id = "animoff",
        title = "Sem Animações",
        short = "Transições desligadas (0x)",
        desc = "Desliga as animações do sistema para a interface responder na hora. Não liga junto com Animações Rápidas. Desativar volta ao valor que estava antes.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "window_animation_scale", "0", "1.0"),
            target(Kind.SETTINGS, "global", "transition_animation_scale", "0", "1.0"),
            target(Kind.SETTINGS, "global", "animator_duration_scale", "0", "1.0")
        ),
        cat = "Tela", sec = "Animações", icon = "⏩",
        group = "anim"
    ),

    Opt(
        id = "timeout",
        title = "Tela Apaga em 30 s",
        short = "Economiza bateria parado",
        desc = "A tela apaga depois de 30 segundos sem toque. Desativar volta ao tempo que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "system", "screen_off_timeout", "30000", "60000")),
        cat = "Tela", sec = "Tela", icon = "⏲"
    ),
    Opt(
        id = "gray",
        title = "Tela em Preto e Branco",
        short = "Sem cores, mais foco",
        desc = "Deixa a tela em tons de cinza (acessibilidade do Android). Ajuda a largar o celular e pode economizar um pouco de bateria em telas OLED. Desativar volta às cores.",
        targets = listOf(
            target(Kind.SETTINGS, "secure", "accessibility_display_daltonizer", "0"),
            target(Kind.SETTINGS, "secure", "accessibility_display_daltonizer_enabled", "1", "0")
        ),
        cat = "Tela", sec = "Cores", icon = "⚫"
    ),

    Opt(
        id = "autorot",
        title = "Sem Giro Automático",
        short = "Tela fica sempre em pé",
        desc = "Desliga o giro automático da tela. Evita giros sem querer e economiza um pouco de bateria. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "system", "accelerometer_rotation", "0", "1")),
        cat = "Tela", sec = "Tela", icon = "🔒"
    ),
    Opt(
        id = "autobright",
        title = "Sem Brilho Automático",
        short = "Você controla o brilho",
        desc = "Desliga o ajuste automático de brilho, que usa o sensor de luz o tempo todo. O brilho fica no valor que você escolher. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "system", "screen_brightness_mode", "0", "1")),
        cat = "Tela", sec = "Tela", icon = "☀️"
    ),

    // ---------------------------------------------------------------- Toque
    Opt(
        id = "haptic",
        title = "Sem Vibração ao Tocar",
        short = "Desliga a vibração do toque",
        desc = "Desliga a vibração de teclado e toques do sistema. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "system", "haptic_feedback_enabled", "0", "1")),
        cat = "Toque", sec = "Feedback", icon = "📳"
    ),
    Opt(
        id = "sounds",
        title = "Sem Sons de Toque",
        short = "Sem cliques e tons",
        desc = "Desliga os sons de toque, do teclado numérico e da tela de bloqueio. Desativar volta ao valor que estava antes.",
        targets = listOf(
            target(Kind.SETTINGS, "system", "sound_effects_enabled", "0", "1"),
            target(Kind.SETTINGS, "system", "dtmf_tone", "0", "1"),
            target(Kind.SETTINGS, "system", "lockscreen_sounds_enabled", "0", "1")
        ),
        cat = "Toque", sec = "Feedback", icon = "🔇"
    ),

    Opt(
        id = "chargesound",
        title = "Carregador Silencioso",
        short = "Sem som e vibração ao plugar",
        desc = "Desliga o som e a vibração de quando o carregador é conectado. Desativar volta ao valor que estava antes.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "charging_sounds_enabled", "0", "1"),
            target(Kind.SETTINGS, "global", "charging_vibration_enabled", "0", "1")
        ),
        cat = "Toque", sec = "Feedback", icon = "🔌"
    ),
    Opt(
        id = "longpress",
        title = "Toque Longo Rápido",
        short = "Segurar responde em 0,25 s",
        desc = "Reduz o tempo de segurar o dedo para ativar o toque longo (o padrão é 0,4 s). Pode ativar sem querer ao rolar a tela.",
        targets = listOf(target(Kind.SETTINGS, "secure", "long_press_timeout", "250", "400")),
        cat = "Toque", sec = "Resposta", icon = "⏱"
    ),
    Opt(
        id = "pointer",
        title = "Ponteiro Veloz",
        short = "Mouse e controle mais rápidos",
        desc = "Aumenta a velocidade do ponteiro de mouse, touchpad ou controle. Não muda nada no toque da tela.",
        targets = listOf(target(Kind.SETTINGS, "system", "pointer_speed", "7")),
        cat = "Toque", sec = "Resposta", icon = "🖱"
    ),
    Opt(
        id = "showtouches",
        title = "Mostrar Toques",
        short = "Ponto onde o dedo toca",
        desc = "Mostra um ponto na tela onde você toca. Bom para gravar vídeos e testar o toque.",
        targets = listOf(target(Kind.SETTINGS, "system", "show_touches", "1", "0")),
        cat = "Toque", sec = "Visualização", icon = "🔘"
    ),
    Opt(
        id = "pointerloc",
        title = "Coordenadas do Toque",
        short = "Rastro e posição do dedo",
        desc = "Mostra no topo da tela as coordenadas e o rastro de cada toque. Bom para testar falhas no toque.",
        targets = listOf(target(Kind.SETTINGS, "system", "pointer_location", "1", "0")),
        cat = "Toque", sec = "Visualização", icon = "📍"
    ),

    // ---------------------------------------------------------------- Internet
    Opt(
        id = "scan",
        title = "Sem Varredura",
        short = "Sem busca contínua de redes",
        desc = "Para a busca constante por redes Wi-Fi e Bluetooth, mesmo com eles desligados. Desativar religa.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "wifi_scan_always_enabled", "0", "1"),
            target(Kind.SETTINGS, "global", "ble_scan_always_enabled", "0", "1")
        ),
        cat = "Internet", sec = "Wi-Fi e Bluetooth", icon = "📡",
        inBulk = true
    ),
    Opt(
        id = "dns",
        title = "DNS Google",
        short = "dns.google",
        desc = "Usa o DNS privado do Google (dns.google). Só um DNS privado fica ligado por vez. Desativar volta ao DNS que estava antes. Requer Android 9+.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            target(Kind.SETTINGS, "global", "private_dns_specifier", "dns.google")
        ),
        cat = "Internet", sec = "DNS privado", icon = "🔒",
        minSdk = 28, group = "dns"
    ),
    Opt(
        id = "dnscf",
        title = "DNS Cloudflare",
        short = "one.one.one.one",
        desc = "Usa o DNS privado da Cloudflare (one.one.one.one). Só um DNS privado fica ligado por vez. Desativar volta ao DNS que estava antes. Requer Android 9+.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            target(Kind.SETTINGS, "global", "private_dns_specifier", "one.one.one.one")
        ),
        cat = "Internet", sec = "DNS privado", icon = "☁️",
        minSdk = 28, group = "dns"
    ),
    Opt(
        id = "dnsag",
        title = "DNS AdGuard",
        short = "Bloqueia anúncios",
        desc = "Usa o DNS privado da AdGuard (dns.adguard-dns.com), que bloqueia anúncios e rastreadores no nível da rede. Alguns apps ou sites podem deixar de carregar. Só um DNS privado fica ligado por vez. Requer Android 9+.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            target(Kind.SETTINGS, "global", "private_dns_specifier", "dns.adguard-dns.com")
        ),
        cat = "Internet", sec = "DNS privado", icon = "🛡",
        minSdk = 28, group = "dns"
    ),

    Opt(
        id = "dnsq9",
        title = "DNS Quad9",
        short = "Bloqueia sites perigosos",
        desc = "Usa o DNS privado da Quad9 (dns.quad9.net), que bloqueia endereços conhecidos de golpe e vírus. Só um DNS privado fica ligado por vez. Desativar volta ao DNS que estava antes. Requer Android 9+.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            target(Kind.SETTINGS, "global", "private_dns_specifier", "dns.quad9.net")
        ),
        cat = "Internet", sec = "DNS privado", icon = "🧱",
        minSdk = 28, group = "dns"
    ),
    Opt(
        id = "captive",
        title = "Sem Teste de Internet",
        short = "Não checa login de Wi-Fi",
        desc = "O Android deixa de testar se a rede tem internet. Redes com página de login (hotéis, cafés) não abrem a página sozinhas. Desativar volta ao padrão.",
        targets = listOf(target(Kind.SETTINGS, "global", "captive_portal_mode", "0", "1")),
        cat = "Internet", sec = "Conexão", icon = "🧪"
    ),
    Opt(
        id = "wifinotif",
        title = "Sem Aviso de Wi-Fi Aberto",
        short = "Sem notificação de redes",
        desc = "Para de avisar quando existem redes Wi-Fi abertas por perto. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "global", "wifi_networks_available_notification_on", "0", "1")),
        cat = "Internet", sec = "Conexão", icon = "📶"
    ),

    // ---------------------------------------------------------------- Sistema
    Opt(
        id = "adaptive",
        title = "Sem Bateria Adaptativa",
        short = "Sem limites automáticos",
        desc = "Desliga a bateria adaptativa, que limita apps que você usa pouco. Apps podem rodar mais em segundo plano e gastar mais bateria. Requer Android 9+.",
        targets = listOf(target(Kind.SETTINGS, "global", "adaptive_battery_management_enabled", "0", "1")),
        cat = "Sistema", sec = "Energia", icon = "🔌",
        minSdk = 28
    ),

    Opt(
        id = "lowpower",
        title = "Economia de Bateria",
        short = "Liga o modo de economia",
        desc = "Liga o modo de economia de bateria do Android. Gasta menos, mas reduz o desempenho e limita apps em segundo plano. O Android pode desligar sozinho ao carregar. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "global", "low_power", "1", "0")),
        cat = "Sistema", sec = "Energia", icon = "🪫"
    ),
    Opt(
        id = "stayon",
        title = "Tela Ligada ao Carregar",
        short = "Não apaga no carregador",
        desc = "Mantém a tela ligada enquanto o aparelho está no carregador. Bom para baixar coisas ou usar como relógio. Em telas OLED, deixe só por pouco tempo para não marcar a tela. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "global", "stay_on_while_plugged_in", "3", "0")),
        cat = "Sistema", sec = "Energia", icon = "🔆"
    ),
    Opt(
        id = "bubbles",
        title = "Sem Bolhas",
        short = "Sem bolhas de notificação",
        desc = "Desliga as notificações em bolha flutuante. Requer Android 10+.",
        targets = listOf(target(Kind.SETTINGS, "secure", "notification_bubbles", "0", "1")),
        cat = "Sistema", sec = "Notificações", icon = "💬",
        minSdk = 29
    ),
    Opt(
        id = "notiflight",
        title = "Sem Luz de Notificação",
        short = "LED de aviso desligado",
        desc = "Desliga a luz piscante de notificação, nos aparelhos que têm. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "system", "notification_light_pulse", "0", "1")),
        cat = "Sistema", sec = "Notificações", icon = "💡"
    )
    )
    // Funções que merecem ler o aviso antes de ligar
    val care = setOf("skiavk", "cached", "captive", "dnsag", "dnsq9", "stayon", "lowpower", "gray", "longpress", "animoff", "adaptive")
    return all.map { if (it.id in care) it.copy(care = true) else it }
}
