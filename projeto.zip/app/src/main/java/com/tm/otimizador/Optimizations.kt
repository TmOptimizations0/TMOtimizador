package com.tm.otimizador

/** Onde o ajuste mora no Android. */
enum class Kind { SETTINGS, DEVCONFIG, PROP }

/**
 * Um valor que o app muda.
 * ns: global/system/secure (SETTINGS) ou o namespace do device_config. Vazio para PROP.
 * on: valor quando a função está ativada.
 * offDefault: valor padrão do Android, usado só se o app não tiver guardado o valor anterior.
 *             null significa apagar a chave (voltar ao padrão do sistema).
 */
data class Target(
    val kind: Kind,
    val ns: String,
    val key: String,
    val on: String,
    val offDefault: String? = null
)

/**
 * Uma função com chave de ativar/desativar.
 * cat: aba onde aparece. sec: seção dentro da aba. icon: símbolo do cartão.
 * short: frase curta do cartão. desc: explicação completa (botão "i").
 * minSdk: versão mínima do Android (API) para a função existir.
 * group: funções do mesmo grupo não ficam ligadas juntas.
 * inBulk: entra em "Ativar pacote seguro" e "Restaurar tudo".
 */
data class Opt(
    val id: String,
    val title: String,
    val short: String,
    val desc: String,
    val targets: List<Target>,
    val cat: String,
    val sec: String,
    val icon: String,
    val minSdk: Int = 24,
    val group: String? = null,
    val inBulk: Boolean = false
)

object Sh {
    fun read(t: Target): String = when (t.kind) {
        Kind.SETTINGS -> "settings get ${t.ns} ${t.key}"
        Kind.DEVCONFIG -> "device_config get ${t.ns} ${t.key}"
        Kind.PROP -> "getprop ${t.key}"
    }

    fun write(t: Target, v: String): String = when (t.kind) {
        Kind.SETTINGS -> "settings put ${t.ns} ${t.key} $v"
        Kind.DEVCONFIG -> "device_config put ${t.ns} ${t.key} $v"
        Kind.PROP -> "setprop ${t.key} $v"
    }

    fun clear(t: Target): String = when (t.kind) {
        Kind.SETTINGS -> "settings delete ${t.ns} ${t.key}"
        Kind.DEVCONFIG -> "device_config delete ${t.ns} ${t.key}"
        Kind.PROP -> "setprop ${t.key} ''"
    }

    /** Compara texto ou número ("90" é igual a "90.0"). */
    fun same(a: String, b: String): Boolean {
        if (a == b) return true
        val x = a.toDoubleOrNull()
        val y = b.toDoubleOrNull()
        return x != null && y != null && x == y
    }
}

/** Abas na ordem em que aparecem. As três primeiras têm chaves; Jogos e Ferramentas têm botões. */
val TABS = listOf(
    "Desempenho" to "⚡",
    "Tela" to "🖥",
    "Internet" to "🌐",
    "Jogos" to "🎮",
    "Ferramentas" to "🧰"
)

val OPTS = listOf(
    Opt(
        id = "phantom",
        title = "Sem Corte Fantasma",
        short = "Apps pesados não são mortos",
        desc = "O Android 12+ mata processos auxiliares dos apps, o que pode fechar jogos e apps pesados. Isto tira esse limite. Requer Android 12+.",
        targets = listOf(
            Target(Kind.DEVCONFIG, "activity_manager", "max_phantom_processes", "2147483647", null),
            Target(Kind.SETTINGS, "global", "settings_enable_monitor_phantom_procs", "false", null)
        ),
        cat = "Desempenho",
        sec = "Memória e processos",
        icon = "👻",
        minSdk = 31,
        inBulk = true
    ),
    Opt(
        id = "freezer",
        title = "Congelar Apps",
        short = "Congela apps minimizados",
        desc = "Liga o congelador de apps minimizados do próprio Android (Android 11+). Em alguns aparelhos só vale depois de reiniciar.",
        targets = listOf(
            Target(Kind.SETTINGS, "global", "cached_apps_freezer", "enabled", "device_default")
        ),
        cat = "Desempenho",
        sec = "Memória e processos",
        icon = "❄️",
        minSdk = 30,
        inBulk = true
    ),
    Opt(
        id = "cached",
        title = "Limite de Cache",
        short = "Máximo de 24 apps em cache",
        desc = "Limita quantos apps fechados o Android mantém na memória. Pode liberar RAM, mas reabre apps do zero mais vezes. O Android pode reverter depois de um tempo. Requer Android 10+.",
        targets = listOf(
            Target(Kind.DEVCONFIG, "activity_manager", "max_cached_processes", "24", null)
        ),
        cat = "Desempenho",
        sec = "Memória e processos",
        icon = "🧠",
        minSdk = 29
    ),
    Opt(
        id = "hzfixed",
        title = "Tela em 90Hz",
        short = "Tela travada em 90Hz",
        desc = "Trava a taxa de atualização em 90Hz. Gasta mais bateria. Algumas marcas ignoram este ajuste.",
        targets = listOf(
            Target(Kind.SETTINGS, "system", "min_refresh_rate", "90.0", null),
            Target(Kind.SETTINGS, "system", "peak_refresh_rate", "90.0", null)
        ),
        cat = "Tela",
        sec = "Taxa de atualização",
        icon = "📺",
        group = "hz"
    ),
    Opt(
        id = "hzadapt",
        title = "Tela Adaptativa",
        short = "Alterna entre 60 e 90Hz",
        desc = "Sobe para 90Hz quando precisa e desce para 60Hz quando a tela está parada. Não liga junto com a de 90Hz fixo.",
        targets = listOf(
            Target(Kind.SETTINGS, "system", "min_refresh_rate", "60.0", null),
            Target(Kind.SETTINGS, "system", "peak_refresh_rate", "90.0", null)
        ),
        cat = "Tela",
        sec = "Taxa de atualização",
        icon = "🔄",
        group = "hz"
    ),
    Opt(
        id = "anim",
        title = "Animações Rápidas",
        short = "Transições em 0.5x",
        desc = "Deixa as transições do sistema mais ágeis. Desativar volta ao valor que estava antes.",
        targets = listOf(
            Target(Kind.SETTINGS, "global", "window_animation_scale", "0.5", "1.0"),
            Target(Kind.SETTINGS, "global", "transition_animation_scale", "0.5", "1.0"),
            Target(Kind.SETTINGS, "global", "animator_duration_scale", "0.5", "1.0")
        ),
        cat = "Tela",
        sec = "Animações",
        icon = "🎬",
        inBulk = true
    ),
    Opt(
        id = "scan",
        title = "Sem Varredura",
        short = "Sem busca contínua de redes",
        desc = "Para a busca constante por redes Wi-Fi e Bluetooth, mesmo com eles desligados. Desativar religa.",
        targets = listOf(
            Target(Kind.SETTINGS, "global", "wifi_scan_always_enabled", "0", "1"),
            Target(Kind.SETTINGS, "global", "ble_scan_always_enabled", "0", "1")
        ),
        cat = "Internet",
        sec = "Wi-Fi e Bluetooth",
        icon = "📡",
        inBulk = true
    ),
    Opt(
        id = "dns",
        title = "DNS Privado",
        short = "Usa o dns.google",
        desc = "Usa DNS privado com dns.google. Desativar volta ao DNS que estava antes.",
        targets = listOf(
            Target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            Target(Kind.SETTINGS, "global", "private_dns_specifier", "dns.google", null)
        ),
        cat = "Internet",
        sec = "DNS",
        icon = "🔒",
        minSdk = 28
    )
)
