package com.tm.otimizador

/** Onde o ajuste mora no Android. */
enum class Kind { SETTINGS, DEVCONFIG, PROP }

/**
 * Um valor que o app muda.
 * ns: global/system/secure (SETTINGS) ou o namespace do device_config. Vazio para PROP.
 * on: valor quando a função está ativada.
 * offDefault: valor padrão do Android, usado só se o app não tiver guardado o valor anterior.
 *             null significa apagar a chave (voltar ao padrão do sistema).
 */
data class Target(
    val kind: Kind,
    val ns: String,
    val key: String,
    val on: String,
    val offDefault: String? = null
)

/**
 * Uma função com chave de ativar/desativar.
 * cat: aba onde aparece. sec: seção dentro da aba. icon: símbolo do cartão.
 * short: frase curta do cartão. desc: explicação completa (botão "i").
 * minSdk: versão mínima do Android (API) para a função existir.
 * group: funções do mesmo grupo não ficam ligadas juntas.
 * inBulk: entra em "Ativar pacote seguro".
 */
data class Opt(
    val id: String,
    val title: String,
    val short: String,
    val desc: String,
    val targets: List<Target>,
    val cat: String,
    val sec: String,
    val icon: String,
    val minSdk: Int = 24,
    val group: String? = null,
    val inBulk: Boolean = false
)

/** Perfil de um toque: lista de funções que ele liga. */
data class Profile(val name: String, val icon: String, val note: String, val ids: List<String>, val freeMemory: Boolean)

object Sh {
    fun read(t: Target): String = when (t.kind) {
        Kind.SETTINGS -> "settings get ${t.ns} ${t.key}"
        Kind.DEVCONFIG -> "device_config get ${t.ns} ${t.key}"
        Kind.PROP -> "getprop ${t.key}"
    }

    fun write(t: Target, v: String): String = when (t.kind) {
        Kind.SETTINGS -> "settings put ${t.ns} ${t.key} $v"
        Kind.DEVCONFIG -> "device_config put ${t.ns} ${t.key} $v"
        Kind.PROP -> "setprop ${t.key} $v"
    }

    fun clear(t: Target): String = when (t.kind) {
        Kind.SETTINGS -> "settings delete ${t.ns} ${t.key}"
        Kind.DEVCONFIG -> "device_config delete ${t.ns} ${t.key}"
        Kind.PROP -> "setprop ${t.key} ''"
    }

    /** Compara texto ou número ("90" é igual a "90.0"). */
    fun same(a: String, b: String): Boolean {
        if (a == b) return true
        val x = a.toDoubleOrNull()
        val y = b.toDoubleOrNull()
        return x != null && y != null && x == y
    }
}

/** Abas na ordem em que aparecem (nome e símbolo). Início, Jogos e Ferramentas não têm chaves. */
val TABS = listOf(
    "Início" to "🏠",
    "Desempenho" to "⚡",
    "Tela" to "🖥",
    "Toque" to "👆",
    "Internet" to "🌐",
    "Sistema" to "⚙️",
    "Jogos" to "🎮",
    "Ferramentas" to "🧰"
)

val PROFILES = listOf(
    Profile(
        "Jogo", "🎮",
        "Libera memória e liga: processos fantasma, congelar apps, animações rápidas, sem varredura e tela em 90Hz.",
        listOf("phantom", "freezer", "anim", "scan", "hzfixed"),
        true
    ),
    Profile(
        "Equilíbrio", "⚖️",
        "Liga: processos fantasma, congelar apps, animações rápidas e tela adaptativa de 60 a 90Hz.",
        listOf("phantom", "freezer", "anim", "hzadapt"),
        false
    ),
    Profile(
        "Bateria", "🔋",
        "Liga: tela em 60Hz, sem varredura em segundo plano e congelar apps.",
        listOf("hz60", "scan", "freezer"),
        false
    )
)

fun target(kind: Kind, ns: String, key: String, on: String, off: String? = null) = Target(kind, ns, key, on, off)

val OPTS = listOf(
    // ---------------------------------------------------------------- Desempenho
    Opt(
        id = "phantom",
        title = "Sem Corte Fantasma",
        short = "Apps pesados não são mortos",
        desc = "O Android 12+ mata processos auxiliares dos apps, o que pode fechar jogos e apps pesados. Isto tira esse limite. Requer Android 12+.",
        targets = listOf(
            target(Kind.DEVCONFIG, "activity_manager", "max_phantom_processes", "2147483647"),
            target(Kind.SETTINGS, "global", "settings_enable_monitor_phantom_procs", "false")
        ),
        cat = "Desempenho", sec = "Memória e processos", icon = "👻",
        minSdk = 31, inBulk = true
    ),
    Opt(
        id = "freezer",
        title = "Congelar Apps",
        short = "Congela apps minimizados",
        desc = "Liga o congelador de apps minimizados do próprio Android (Android 11+). Em alguns aparelhos só vale depois de reiniciar.",
        targets = listOf(target(Kind.SETTINGS, "global", "cached_apps_freezer", "enabled", "device_default")),
        cat = "Desempenho", sec = "Memória e processos", icon = "❄️",
        minSdk = 30, inBulk = true
    ),
    Opt(
        id = "cached",
        title = "Limite de Cache",
        short = "Máximo de 24 apps em cache",
        desc = "Limita quantos apps fechados o Android mantém na memória. Pode liberar RAM, mas reabre apps do zero mais vezes. O Android pode reverter depois de um tempo. Requer Android 10+.",
        targets = listOf(target(Kind.DEVCONFIG, "activity_manager", "max_cached_processes", "24")),
        cat = "Desempenho", sec = "Memória e processos", icon = "🧠",
        minSdk = 29
    ),

    // ---------------------------------------------------------------- Tela
    Opt(
        id = "hz60",
        title = "Tela em 60Hz",
        short = "Economiza bateria",
        desc = "Trava a tela em 60Hz para gastar menos bateria. Não liga junto com as outras opções de taxa de atualização.",
        targets = listOf(
            target(Kind.SETTINGS, "system", "min_refresh_rate", "60.0"),
            target(Kind.SETTINGS, "system", "peak_refresh_rate", "60.0")
        ),
        cat = "Tela", sec = "Taxa de atualização", icon = "🔋",
        group = "hz"
    ),
    Opt(
        id = "hzfixed",
        title = "Tela em 90Hz",
        short = "Tela travada em 90Hz",
        desc = "Trava a taxa de atualização em 90Hz. Gasta mais bateria. Algumas marcas ignoram este ajuste.",
        targets = listOf(
            target(Kind.SETTINGS, "system", "min_refresh_rate", "90.0"),
            target(Kind.SETTINGS, "system", "peak_refresh_rate", "90.0")
        ),
        cat = "Tela", sec = "Taxa de atualização", icon = "📺",
        group = "hz"
    ),
    Opt(
        id = "hzadapt",
        title = "Tela Adaptativa",
        short = "Alterna entre 60 e 90Hz",
        desc = "Sobe para 90Hz quando precisa e desce para 60Hz quando a tela está parada. Não liga junto com as outras opções de taxa de atualização.",
        targets = listOf(
            target(Kind.SETTINGS, "system", "min_refresh_rate", "60.0"),
            target(Kind.SETTINGS, "system", "peak_refresh_rate", "90.0")
        ),
        cat = "Tela", sec = "Taxa de atualização", icon = "🔄",
        group = "hz"
    ),
    Opt(
        id = "anim",
        title = "Animações Rápidas",
        short = "Transições em 0.5x",
        desc = "Deixa as transições do sistema mais ágeis. Não liga junto com Sem Animações. Desativar volta ao valor que estava antes.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "window_animation_scale", "0.5", "1.0"),
            target(Kind.SETTINGS, "global", "transition_animation_scale", "0.5", "1.0"),
            target(Kind.SETTINGS, "global", "animator_duration_scale", "0.5", "1.0")
        ),
        cat = "Tela", sec = "Animações", icon = "🎬",
        group = "anim", inBulk = true
    ),
    Opt(
        id = "animoff",
        title = "Sem Animações",
        short = "Transições desligadas (0x)",
        desc = "Desliga as animações do sistema para a interface responder na hora. Não liga junto com Animações Rápidas. Desativar volta ao valor que estava antes.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "window_animation_scale", "0", "1.0"),
            target(Kind.SETTINGS, "global", "transition_animation_scale", "0", "1.0"),
            target(Kind.SETTINGS, "global", "animator_duration_scale", "0", "1.0")
        ),
        cat = "Tela", sec = "Animações", icon = "⏩",
        group = "anim"
    ),

    // ---------------------------------------------------------------- Toque
    Opt(
        id = "haptic",
        title = "Sem Vibração ao Tocar",
        short = "Desliga a vibração do toque",
        desc = "Desliga a vibração de teclado e toques do sistema. Desativar volta ao valor que estava antes.",
        targets = listOf(target(Kind.SETTINGS, "system", "haptic_feedback_enabled", "0", "1")),
        cat = "Toque", sec = "Feedback", icon = "📳"
    ),
    Opt(
        id = "sounds",
        title = "Sem Sons de Toque",
        short = "Sem cliques e tons",
        desc = "Desliga os sons de toque, do teclado numérico e da tela de bloqueio. Desativar volta ao valor que estava antes.",
        targets = listOf(
            target(Kind.SETTINGS, "system", "sound_effects_enabled", "0", "1"),
            target(Kind.SETTINGS, "system", "dtmf_tone", "0", "1"),
            target(Kind.SETTINGS, "system", "lockscreen_sounds_enabled", "0", "1")
        ),
        cat = "Toque", sec = "Feedback", icon = "🔇"
    ),
    Opt(
        id = "longpress",
        title = "Toque Longo Rápido",
        short = "Segurar responde em 0,25 s",
        desc = "Reduz o tempo de segurar o dedo para ativar o toque longo (o padrão é 0,4 s). Pode ativar sem querer ao rolar a tela.",
        targets = listOf(target(Kind.SETTINGS, "secure", "long_press_timeout", "250", "400")),
        cat = "Toque", sec = "Resposta", icon = "⏱"
    ),
    Opt(
        id = "pointer",
        title = "Ponteiro Veloz",
        short = "Mouse e controle mais rápidos",
        desc = "Aumenta a velocidade do ponteiro de mouse, touchpad ou controle. Não muda nada no toque da tela.",
        targets = listOf(target(Kind.SETTINGS, "system", "pointer_speed", "7")),
        cat = "Toque", sec = "Resposta", icon = "🖱"
    ),
    Opt(
        id = "showtouches",
        title = "Mostrar Toques",
        short = "Ponto onde o dedo toca",
        desc = "Mostra um ponto na tela onde você toca. Bom para gravar vídeos e testar o toque.",
        targets = listOf(target(Kind.SETTINGS, "system", "show_touches", "1", "0")),
        cat = "Toque", sec = "Visualização", icon = "🔘"
    ),
    Opt(
        id = "pointerloc",
        title = "Coordenadas do Toque",
        short = "Rastro e posição do dedo",
        desc = "Mostra no topo da tela as coordenadas e o rastro de cada toque. Bom para testar falhas no toque.",
        targets = listOf(target(Kind.SETTINGS, "system", "pointer_location", "1", "0")),
        cat = "Toque", sec = "Visualização", icon = "📍"
    ),

    // ---------------------------------------------------------------- Internet
    Opt(
        id = "scan",
        title = "Sem Varredura",
        short = "Sem busca contínua de redes",
        desc = "Para a busca constante por redes Wi-Fi e Bluetooth, mesmo com eles desligados. Desativar religa.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "wifi_scan_always_enabled", "0", "1"),
            target(Kind.SETTINGS, "global", "ble_scan_always_enabled", "0", "1")
        ),
        cat = "Internet", sec = "Wi-Fi e Bluetooth", icon = "📡",
        inBulk = true
    ),
    Opt(
        id = "dns",
        title = "DNS Google",
        short = "dns.google",
        desc = "Usa o DNS privado do Google (dns.google). Só um DNS privado fica ligado por vez. Desativar volta ao DNS que estava antes. Requer Android 9+.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            target(Kind.SETTINGS, "global", "private_dns_specifier", "dns.google")
        ),
        cat = "Internet", sec = "DNS privado", icon = "🔒",
        minSdk = 28, group = "dns"
    ),
    Opt(
        id = "dnscf",
        title = "DNS Cloudflare",
        short = "one.one.one.one",
        desc = "Usa o DNS privado da Cloudflare (one.one.one.one). Só um DNS privado fica ligado por vez. Desativar volta ao DNS que estava antes. Requer Android 9+.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            target(Kind.SETTINGS, "global", "private_dns_specifier", "one.one.one.one")
        ),
        cat = "Internet", sec = "DNS privado", icon = "☁️",
        minSdk = 28, group = "dns"
    ),
    Opt(
        id = "dnsag",
        title = "DNS AdGuard",
        short = "Bloqueia anúncios",
        desc = "Usa o DNS privado da AdGuard (dns.adguard-dns.com), que bloqueia anúncios e rastreadores no nível da rede. Alguns apps ou sites podem deixar de carregar. Só um DNS privado fica ligado por vez. Requer Android 9+.",
        targets = listOf(
            target(Kind.SETTINGS, "global", "private_dns_mode", "hostname", "opportunistic"),
            target(Kind.SETTINGS, "global", "private_dns_specifier", "dns.adguard-dns.com")
        ),
        cat = "Internet", sec = "DNS privado", icon = "🛡",
        minSdk = 28, group = "dns"
    ),
    Opt(
        id = "captive",
        title = "Sem Teste de Internet",
        short = "Não checa login de Wi-Fi",
        desc = "O Android deixa de testar se a rede tem internet. Redes com página de login (hotéis, cafés) não abrem a página sozinhas. Desativar volta ao padrão.",
        targets = listOf(target(Kind.SETTINGS, "global", "captive_portal_mode", "0", "1")),
        cat = "Internet", sec = "Conexão", icon = "🧪"
    ),

    // ---------------------------------------------------------------- Sistema
    Opt(
        id = "adaptive",
        title = "Sem Bateria Adaptativa",
        short = "Sem limites automáticos",
        desc = "Desliga a bateria adaptativa, que limita apps que você usa pouco. Apps podem rodar mais em segundo plano e gastar mais bateria. Requer Android 9+.",
        targets = listOf(target(Kind.SETTINGS, "global", "adaptive_battery_management_enabled", "0", "1")),
        cat = "Sistema", sec = "Energia", icon = "🔌",
        minSdk = 28
    ),
    Opt(
        id = "bubbles",
        title = "Sem Bolhas",
        short = "Sem bolhas de notificação",
        desc = "Desliga as notificações em bolha flutuante. Requer Android 10+.",
        targets = listOf(target(Kind.SETTINGS, "secure", "notification_bubbles", "0", "1")),
        cat = "Sistema", sec = "Notificações", icon = "💬",
        minSdk = 29
    )
)
