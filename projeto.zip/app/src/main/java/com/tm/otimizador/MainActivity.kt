package com.tm.otimizador

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private companion object {
        var savedLog = ""
    }

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("opts", MODE_PRIVATE) }
    private val sdk = Build.VERSION.SDK_INT
    private val br = Locale.forLanguageTag("pt-BR")
    private val pkgRegex = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    // Cores. A cor de destaque vem da paleta escolhida (padrão: Azul); o resto é calculado a partir dela.
    private var cBgTop = Color.parseColor("#000814")
    private var cBgBottom = Color.parseColor("#01030A")
    private var cCard = Color.parseColor("#09121F")
    private var cActive = Color.parseColor("#0B2B3B")
    private var cTile = Color.parseColor("#0F2230")
    private var cField = Color.parseColor("#050C16")
    private var cStrokeOff = Color.parseColor("#12303F")
    private var cCyan = Color.parseColor("#22D3EE")
    private var cCyanDark = Color.parseColor("#0E7490")
    private val cText = Color.parseColor("#E6F1FF")
    private val cMuted = Color.parseColor("#8AA0B8")
    private val cWarn = Color.parseColor("#FBBF24")
    private val cOk = Color.parseColor("#34D399")
    private val cInk = Color.parseColor("#001018")

    /** Uma seção de uma aba: título e grade de cartões. */
    private class Sec(val tab: String, val label: View, val grid: GridLayout) {
        val cards = ArrayList<Pair<Opt, View>>()
    }

    private val switches = LinkedHashMap<String, Switch>()
    private val cardBg = HashMap<String, GradientDrawable>()
    private val actionButtons = ArrayList<Button>()
    private val tabViews = LinkedHashMap<String, LinearLayout>()
    private val chipViews = LinkedHashMap<String, TextView>()
    private val sections = ArrayList<Sec>()
    private val statValues = HashMap<String, TextView>()
    private val statSubs = HashMap<String, TextView>()
    /** Maior taxa de atualização suportada pela tela (60 se não conseguir ler). */
    @Suppress("DEPRECATION")
    private fun detectMaxHz(): Int {
        return try {
            val modes = windowManager.defaultDisplay.supportedModes
            val m = modes.maxOf { it.refreshRate }
            Math.round(m).coerceIn(60, 240)
        } catch (t: Throwable) {
            60
        }
    }

    // Funções adaptadas a este aparelho (taxa de tela e marca). Esta lista tem o mesmo nome da lista global de propósito.
    private val OPTS: List<Opt> by lazy { buildOpts(detectMaxHz(), Build.MANUFACTURER.lowercase()) }
    private val optTabs: Set<String> by lazy { OPTS.map { it.cat }.toSet() }

    private lateinit var contentScroll: ScrollView
    private lateinit var searchInput: EditText
    private lateinit var status: TextView
    private lateinit var statusDot: GradientDrawable
    private lateinit var permButton: Button
    private lateinit var bottomStatus: TextView
    private lateinit var pkgInput: EditText
    private lateinit var gameLabel: TextView
    private val profileButtons = HashMap<String, Button>()
    private val profileStatus = ArrayList<TextView>()

    private var currentTab = TABS[0].first
    private var logText: String
        get() = savedLog
        set(v) { savedLog = v }
    private var suppress = false
    private var connected = false

    private val binderReceived = Shizuku.OnBinderReceivedListener { ui.post { refreshState() } }
    private val binderDead = Shizuku.OnBinderDeadListener { ui.post { refreshState() } }
    private val permResult = Shizuku.OnRequestPermissionResultListener { _, _ -> ui.post { refreshState() } }

    // ---------------------------------------------------------------- paleta de cores

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun applyPalette(index: Int) {
        val p = PALETTES[index.coerceIn(0, PALETTES.size - 1)]
        val acc = p.accent.toInt()
        val base = Color.parseColor("#06101C")
        cCyan = acc
        cCyanDark = mix(acc, Color.BLACK, 0.45f)
        cActive = mix(base, acc, 0.22f)
        cTile = mix(base, acc, 0.14f)
        cStrokeOff = mix(base, acc, 0.17f)
        cCard = mix(Color.parseColor("#050B14"), acc, 0.045f)
        cField = mix(Color.parseColor("#030812"), acc, 0.03f)
        cBgTop = mix(Color.parseColor("#000610"), acc, 0.03f)
        cBgBottom = Color.parseColor("#01030A")
    }

    private fun pickPalette() {
        val cur = prefs.getInt("palette", 0)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))
        val grid = GridLayout(this)
        grid.columnCount = 3
        val dlg = AlertDialog.Builder(this).setTitle("Cor do app").setView(box).setNegativeButton("Fechar", null).create()
        for ((i, p) in PALETTES.withIndex()) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.setPadding(dp(6), dp(8), dp(6), dp(8))
            val dot = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(p.accent.toInt())
            if (i == cur) g.setStroke(dp(3), Color.WHITE) else g.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            dot.background = g
            dot.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            val label = text(p.name, 11.5f, cText)
            label.gravity = Gravity.CENTER
            label.layoutParams = lp(4)
            item.addView(dot)
            item.addView(label)
            val gl = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            gl.width = 0
            gl.setGravity(Gravity.FILL)
            item.layoutParams = gl
            item.setOnClickListener {
                prefs.edit().putInt("palette", i).apply()
                dlg.dismiss()
                recreate()
            }
            grid.addView(item)
        }
        box.addView(grid)
        dlg.show()
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyPalette(prefs.getInt("palette", 0))
        window.statusBarColor = cBgTop
        window.navigationBarColor = cBgBottom
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permResult)
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permResult)
        worker.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- Shizuku

    private fun running(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (t: Throwable) {
            false
        }
    }

    private fun granted(): Boolean {
        if (!running()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (t: Throwable) {
            false
        }
    }

    private fun onPermClick() {
        if (!running()) {
            val intent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                startActivity(intent)
            } else {
                toast("Shizuku não está instalado. Instale e inicie o serviço.")
            }
            return
        }
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Permissão negada. Libere o TM Otimizador dentro do app Shizuku.")
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (t: Throwable) {
            toast("Erro ao pedir permissão: ${t.message}")
        }
    }

    /** Executa um comando de shell com a permissão do Shizuku. Retorna (código, saída). */
    private fun exec(cmd: String): Pair<Int, String> {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            Pair(code, out.trim())
        } catch (t: Throwable) {
            Pair(-1, t.cause?.message ?: t.message ?: t.toString())
        }
    }

    // ---------------------------------------------------------------- leitura / escrita dos ajustes

    private fun supported(opt: Opt): Boolean = sdk >= opt.minSdk && opt.unavailable == null

    /** Valor atual: texto, "" se a chave não existe, null se a leitura falhou. */
    private fun readTarget(t: Target): String? {
        val r = exec(Sh.read(t))
        if (r.first != 0) return null
        val v = r.second.trim()
        return if (v == "null" || v.isEmpty()) "" else v
    }

    private fun isActive(opt: Opt): Boolean {
        for (t in opt.targets) {
            val v = readTarget(t) ?: return false
            if (!Sh.same(v, t.on)) return false
        }
        return true
    }

    /** Ativa guardando o valor anterior e confere o resultado. Bloqueante. */
    private fun enableOpt(opt: Opt): Boolean {
        log("Ativando: " + opt.title + "…")

        // Funções do mesmo grupo não ficam ligadas juntas.
        val grp = opt.group
        if (grp != null) {
            for (other in OPTS) {
                if (other.id != opt.id && other.group == grp && supported(other) && isActive(other)) {
                    disableOpt(other)
                    ui.post { setSwitch(other.id, false) }
                }
            }
        }

        val cur = opt.targets.map { readTarget(it) }
        val already = opt.targets.indices.all { i ->
            val v = cur[i]
            v != null && Sh.same(v, opt.targets[i].on)
        }
        if (!already) {
            val ed = prefs.edit()
            ed.putBoolean("has_prev_" + opt.id, true)
            for (i in opt.targets.indices) {
                ed.putString("prev_" + opt.id + "_" + i, cur[i] ?: "")
            }
            ed.apply()
        }

        for (t in opt.targets) {
            val r = exec(Sh.write(t, t.on))
            if (r.first != 0) log("  ✘ " + t.key + ": " + r.second.take(200))
        }

        return if (isActive(opt)) {
            log("✔ ativado: " + opt.title)
            true
        } else {
            log("✘ o Android não aceitou: " + opt.title + ". Seu aparelho ou sua versão pode ignorar este ajuste.")
            false
        }
    }

    /** Desativa voltando ao valor que estava antes. Bloqueante. */
    private fun disableOpt(opt: Opt): Boolean {
        log("Desativando: " + opt.title + "…")
        val has = prefs.getBoolean("has_prev_" + opt.id, false)
        for (i in opt.targets.indices) {
            val t = opt.targets[i]
            if (has) {
                val prev = prefs.getString("prev_" + opt.id + "_" + i, "") ?: ""
                if (prev.isEmpty()) exec(Sh.clear(t)) else exec(Sh.write(t, prev))
            } else {
                val d = t.offDefault
                if (d != null) exec(Sh.write(t, d)) else exec(Sh.clear(t))
            }
        }
        val ed = prefs.edit()
        ed.remove("has_prev_" + opt.id)
        for (i in opt.targets.indices) ed.remove("prev_" + opt.id + "_" + i)
        ed.apply()

        return if (!isActive(opt)) {
            log("✔ desativado, valor anterior restaurado: " + opt.title)
            true
        } else {
            log("✘ não consegui desativar: " + opt.title + ". Tente de novo ou reinicie o aparelho.")
            false
        }
    }

    // ---------------------------------------------------------------- estado da tela

    private fun refreshState() {
        val run = running()
        connected = granted()
        when {
            !run -> {
                status.text = "Shizuku não está em execução"
                statusDot.setColor(cWarn)
                permButton.text = "Abrir Shizuku"
                permButton.visibility = View.VISIBLE
            }
            !connected -> {
                status.text = "Shizuku ativo, falta a permissão"
                statusDot.setColor(cWarn)
                permButton.text = "Conceder"
                permButton.visibility = View.VISIBLE
            }
            else -> {
                status.text = "Shizuku conectado"
                statusDot.setColor(cOk)
                permButton.visibility = View.GONE
            }
        }
        setBusy(false)
        updateStats()
        if (connected) syncStates()
    }

    /** Lê o estado real de cada função no aparelho e ajusta as chaves. */
    private fun syncStates() {
        worker.execute {
            for (opt in OPTS) {
                if (!supported(opt)) continue
                val state = isActive(opt)
                ui.post { setSwitch(opt.id, state) }
            }
        }
    }

    private fun setSwitch(id: String, value: Boolean) {
        val s = switches[id] ?: return
        suppress = true
        s.isChecked = value
        suppress = false
        val bg = cardBg[id]
        if (bg != null) {
            bg.setColor(if (value) cActive else cCard)
            bg.setStroke(dp(if (value) 2 else 1), if (value) cCyan else cStrokeOff)
        }
        updateStats()
    }

    private fun setBusy(busy: Boolean) {
        for (opt in OPTS) {
            switches[opt.id]?.isEnabled = !busy && connected && supported(opt)
        }
        for (b in actionButtons) {
            b.isEnabled = !busy && connected
            b.alpha = if (b.isEnabled) 1f else 0.4f
        }
    }

    // ---------------------------------------------------------------- painel do aparelho

    private fun fmt(v: Double): String = String.format(br, "%.1f", v)

    private fun gb(bytes: Long): String = fmt(bytes / 1073741824.0) + " GB"

    private fun setStat(key: String, value: String, sub: String) {
        statValues[key]?.text = value
        statSubs[key]?.text = sub
    }

    @Suppress("DEPRECATION")
    private fun updateStats() {
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            setStat("ram", gb(mi.availMem), "livres de " + gb(mi.totalMem))

            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale).toString() + "%" else "—"
            setStat("bat", pct, fmt(temp) + " °C · " + (if (charging) "carregando" else "descarregando"))

            val sf = StatFs(Environment.getDataDirectory().path)
            setStat("disk", gb(sf.availableBytes), "livres de " + gb(sf.totalBytes))

            val hz = windowManager.defaultDisplay.refreshRate
            setStat("hz", String.format(br, "%.0f Hz", hz), "agora · máximo " + detectMaxHz() + " Hz")

            val on = switches.values.count { it.isChecked }
            val total = OPTS.count { supported(it) }
            setStat("act", "$on de $total", "funções ligadas")

            val sup = OPTS.count { supported(it) }
            setStat("sup", "$sup de ${OPTS.size}", "funções que servem neste aparelho")
            setStat("dev", Build.MANUFACTURER.replaceFirstChar { it.uppercase() }, Build.MODEL)
            setStat("and", "Android " + Build.VERSION.RELEASE, "API " + sdk)
        } catch (t: Throwable) {
            // o painel é só informativo; nunca derruba o app
        }
    }

    // ---------------------------------------------------------------- ações

    private fun onToggle(opt: Opt, checked: Boolean) {
        if (suppress) return
        if (!connected) {
            setSwitch(opt.id, !checked)
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            if (checked) enableOpt(opt) else disableOpt(opt)
            val real = isActive(opt)
            ui.post {
                setSwitch(opt.id, real)
                setBusy(false)
            }
        }
    }

    private fun bulk(enable: Boolean) {
        if (!connected) {
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            for (opt in OPTS) {
                if (!supported(opt)) continue
                if (enable) {
                    if (!opt.inBulk) continue
                    enableOpt(opt)
                } else {
                    // Restaurar só mexe no que este app ligou e guardou o valor anterior.
                    if (!prefs.getBoolean("has_prev_" + opt.id, false)) continue
                    disableOpt(opt)
                }
                val real = isActive(opt)
                ui.post { setSwitch(opt.id, real) }
            }
            if (!enable) prefs.edit().remove("active_profile").apply()
            ui.post {
                setBusy(false)
                refreshProfileUi()
            }
        }
    }

    private fun activeProfile(): String = prefs.getString("active_profile", "") ?: ""

    private fun refreshProfileUi() {
        val cur = activeProfile()
        val txt = if (cur.isEmpty()) "Nenhum perfil ativo" else "Perfil ativo: $cur"
        for (t in profileStatus) t.text = txt
        for ((name, b) in profileButtons) {
            val on = name == cur
            b.text = if (on) "✔  Ativo" else "Ativar"
            b.background = if (on) shape(Color.TRANSPARENT, 14, cCyan, 2) else shape(cCyan, 14)
            b.setTextColor(if (on) cCyan else cInk)
        }
    }

    /** Liga as funções do perfil e desfaz as que o app ligou antes e não fazem parte dele. */
    private fun applyProfile(p: Profile) {
        if (!connected) {
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            log("Perfil " + p.name + "…")
            // 1) desfaz o que ficou de outro perfil
            val keep = p.ids.toSet()
            val managed = PROFILES.flatMap { it.ids }.toSet()
            for (opt in OPTS) {
                if (opt.id in managed && opt.id !in keep && supported(opt) && prefs.getBoolean("has_prev_" + opt.id, false)) {
                    disableOpt(opt)
                    val real = isActive(opt)
                    ui.post { setSwitch(opt.id, real) }
                }
            }
            // 2) liga o que o perfil pede
            var ok = 0
            var skipped = 0
            for (id in p.ids) {
                val opt = OPTS.firstOrNull { it.id == id } ?: continue
                if (!supported(opt)) {
                    log("— " + opt.title + ": indisponível neste aparelho")
                    skipped++
                    continue
                }
                if (enableOpt(opt)) ok++
                val real = isActive(opt)
                ui.post { setSwitch(opt.id, real) }
            }
            if (p.freeMemory) {
                val k = exec("am kill-all")
                log(if (k.first == 0) "✔ memória liberada" else "✘ liberar memória: " + k.second.take(200))
            }
            prefs.edit().putString("active_profile", p.name).apply()
            log("✔ perfil " + p.name + " aplicado: " + ok + " funções ligadas" + (if (skipped > 0) ", " + skipped + " indisponíveis" else ""))
            ui.post {
                setBusy(false)
                refreshProfileUi()
            }
        }
    }

    /** Roda um comando e mostra a resposta numa janela (para diagnóstico). */
    private fun runShow(title: String, cmd: String) {
        if (!connected) {
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            log("$title…")
            val r = exec(cmd)
            val out = if (r.second.isBlank()) "Sem resposta. Este comando pode não existir no seu Android." else r.second.take(6000)
            log(if (r.first == 0) "✔ $title" else "✘ $title (" + r.first + ")")
            ui.post {
                setBusy(false)
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(out)
                    .setPositiveButton("Fechar", null)
                    .show()
            }
        }
    }

    private fun runAction(label: String, cmd: String) {
        if (!connected) {
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            log("$label…")
            val r = exec(cmd)
            if (r.first == 0) log("✔ concluído" + snip(r.second)) else log("✘ erro (" + r.first + "): " + r.second.take(300))
            ui.post { setBusy(false) }
        }
    }

    // ---------------------------------------------------------------- jogos

    /** Lê o pacote digitado. O nome é validado antes de ir para o shell. */
    private fun currentPkg(): String? {
        val pkg = pkgInput.text.toString().trim()
        if (!pkgRegex.matches(pkg)) {
            toast("Digite ou escolha um jogo. O nome do pacote parece com com.exemplo.jogo")
            return null
        }
        prefs.edit().putString("last_pkg", pkg).apply()
        return pkg
    }

    private fun gameAction(kind: String) {
        val pkg = currentPkg() ?: return
        if (sdk < 31) {
            toast("O modo Game exige Android 12 ou mais novo")
            return
        }
        when (kind) {
            "performance" -> runAction("Modo desempenho em $pkg", "cmd game mode performance $pkg")
            "reset" -> runAction("Voltando $pkg ao padrão", "cmd game reset $pkg")
            else -> runShow("Modos de $pkg", "cmd game list-modes $pkg")
        }
    }

    private fun pickFps() {
        val pkg = currentPkg() ?: return
        if (sdk < 34) {
            toast("Limitar o FPS exige Android 14 ou mais novo")
            return
        }
        val opts = arrayOf("30 FPS", "45 FPS", "60 FPS", "90 FPS", "120 FPS")
        val vals = intArrayOf(30, 45, 60, 90, 120)
        AlertDialog.Builder(this)
            .setTitle("FPS máximo do jogo")
            .setItems(opts) { _, i ->
                runAction("Limitando $pkg a " + vals[i] + " FPS", "cmd game set --mode performance --fps " + vals[i] + " $pkg")
            }
            .show()
    }

    private fun compileGame() {
        val pkg = currentPkg() ?: return
        runAction("Compilando $pkg, pode levar alguns minutos", "cmd package compile -m speed -f $pkg")
    }

    private fun stopGame() {
        val pkg = currentPkg() ?: return
        runAction("Parando $pkg", "am force-stop $pkg")
    }

    /** Libera memória, liga o modo desempenho (Android 12+) e abre o jogo. */
    private fun prepareGame() {
        val pkg = currentPkg() ?: return
        if (!connected) {
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            log("Preparando $pkg…")
            val k = exec("am kill-all")
            log(if (k.first == 0) "✔ memória liberada" else "✘ liberar memória: " + k.second.take(200))
            if (sdk >= 31) {
                val g = exec("cmd game mode performance $pkg")
                log(if (g.first == 0) "✔ modo desempenho" else "✘ modo Game: " + g.second.take(200))
            } else {
                log("— modo Game pulado: exige Android 12 ou mais novo")
            }
            ui.post {
                setBusy(false)
                val li = packageManager.getLaunchIntentForPackage(pkg)
                if (li != null) startActivity(li) else toast("Não achei como abrir $pkg")
            }
        }
    }

    /** Lista os apps com ícone na gaveta para escolher o jogo. */
    private fun pickApp() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        if (apps.isEmpty()) {
            toast("Não consegui listar os apps. Digite o pacote à mão.")
            return
        }
        val names = apps.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolha o jogo")
            .setItems(names) { _, i ->
                pkgInput.setText(apps[i].second)
                gameLabel.text = "Jogo escolhido: " + apps[i].first
            }
            .show()
    }

    // ---------------------------------------------------------------- registro

    private fun snip(s: String): String = if (s.isBlank()) "" else ": " + s.take(500)

    private fun log(msg: String) {
        ui.post {
            logText = (logText + msg + "\n").takeLast(8000)
            bottomStatus.text = "▲  " + msg.trim()
        }
    }

    private fun showLog() {
        AlertDialog.Builder(this)
            .setTitle("Registro")
            .setMessage(if (logText.isBlank()) "Nada por aqui ainda." else logText)
            .setPositiveButton("Fechar", null)
            .setNeutralButton("Copiar") { _, _ -> copyLog() }
            .show()
    }

    private fun copyLog() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("registro", logText))
        toast("Registro copiado")
    }

    private fun clearLog() {
        logText = ""
        bottomStatus.text = "Pronto  ·  toque aqui para ver o registro"
        toast("Registro limpo")
    }

    private fun showInfo(opt: Opt) {
        val cmds = opt.targets.joinToString("\n") { "• " + Sh.write(it, it.on) }
        var msg = opt.desc + "\n\nO que o app muda:\n" + cmds
        if (opt.unavailable != null) {
            msg += "\n\n" + opt.unavailable + "."
        } else if (!supported(opt)) {
            msg += "\n\nSeu Android é o API " + sdk + ". Esta função precisa do API " + opt.minSdk + "."
        }
        AlertDialog.Builder(this)
            .setTitle(opt.title)
            .setMessage(msg)
            .setPositiveButton("Entendi", null)
            .show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- abas e busca

    private fun selectTab(tab: String) {
        currentTab = tab
        for ((k, v) in chipViews) styleChip(v, k == tab)
        searchInput.setText("")
        applyFilter()
        contentScroll.scrollTo(0, 0)
        if (tab == "Início") updateStats()
    }

    private fun styleChip(t: TextView, selected: Boolean) {
        if (selected) {
            t.setTextColor(cInk)
            t.background = shape(cCyan, 22)
        } else {
            t.setTextColor(cText)
            t.background = shape(cCard, 22, cStrokeOff, 1)
        }
    }

    /** Mostra só a aba escolhida; com busca, mostra os cartões que combinam em todas as abas de chaves. */
    private fun applyFilter() {
        val q = searchInput.text.toString().trim().lowercase()
        val searching = q.isNotEmpty()
        for ((tab, box) in tabViews) {
            val show = if (searching) optTabs.contains(tab) else tab == currentTab
            box.visibility = if (show) View.VISIBLE else View.GONE
        }
        for (s in sections) {
            var any = false
            for (p in s.cards) {
                val o = p.first
                val match = !searching ||
                    o.title.lowercase().contains(q) ||
                    o.short.lowercase().contains(q) ||
                    o.desc.lowercase().contains(q)
                p.second.visibility = if (match) View.VISIBLE else View.GONE
                if (match) any = true
            }
            val vis = if (any) View.VISIBLE else View.GONE
            s.label.visibility = vis
            s.grid.visibility = vis
        }
    }

    // ---------------------------------------------------------------- interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, radiusDp: Int, strokeColor: Int? = null, strokeDp: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != null) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(top)
        return p
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = shape(cCard, 18, cStrokeOff, 1)
        c.layoutParams = lp(10)
        return c
    }

    /** Botão cheio (principal) ou só contorno (secundário). */
    private fun btn(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.stateListAnimator = null
        b.textSize = 14f
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.minHeight = dp(48)
        if (primary) {
            b.setTextColor(cInk)
            b.background = shape(cCyan, 14)
        } else {
            b.setTextColor(cCyan)
            b.background = shape(Color.TRANSPARENT, 14, cCyanDark, 1)
        }
        b.setOnClickListener { onClick() }
        b.layoutParams = lp(10)
        return b
    }

    private fun actionBtn(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = btn(label, primary, onClick)
        b.isEnabled = false
        b.alpha = 0.4f
        actionButtons.add(b)
        return b
    }

    /** Célula da grade de 2 colunas. */
    private fun cell(): GridLayout.LayoutParams {
        val p = GridLayout.LayoutParams(
            GridLayout.spec(GridLayout.UNDEFINED),
            GridLayout.spec(GridLayout.UNDEFINED, 1f)
        )
        p.width = 0
        p.setMargins(dp(5), dp(5), dp(5), dp(5))
        p.setGravity(Gravity.FILL)
        return p
    }

    private fun sectionLabel(title: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = lp(18)
        row.setPadding(dp(6), 0, 0, dp(4))
        val bar = View(this)
        bar.background = shape(cCyan, 2)
        val barLp = LinearLayout.LayoutParams(dp(3), dp(14))
        barLp.rightMargin = dp(10)
        bar.layoutParams = barLp
        val t = text(title.uppercase(), 12f, cCyan, bold = true)
        t.letterSpacing = 0.16f
        row.addView(bar)
        row.addView(t)
        return row
    }

    private fun newGrid(): GridLayout {
        val g = GridLayout(this)
        g.columnCount = 2
        g.layoutParams = lp(0)
        return g
    }

    private fun statCard(key: String, label: String): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.background = shape(cCard, 18, cStrokeOff, 1)
        val l = text(label, 10.5f, cCyan, bold = true)
        l.letterSpacing = 0.14f
        c.addView(l)
        val v = text("—", 20f, cText, bold = true)
        v.layoutParams = lp(4)
        v.maxLines = 1
        v.ellipsize = TextUtils.TruncateAt.END
        c.addView(v)
        val s = text("", 11.5f, cMuted)
        s.layoutParams = lp(2)
        s.maxLines = 2
        s.ellipsize = TextUtils.TruncateAt.END
        c.addView(s)
        statValues[key] = v
        statSubs[key] = s
        c.layoutParams = cell()
        return c
    }

    private fun optCard(opt: Opt): View {
        val ok = supported(opt)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(12), dp(12), dp(12))
        val bg = shape(cCard, 18, cStrokeOff, 1)
        c.background = bg
        cardBg[opt.id] = bg
        if (!ok) c.alpha = 0.55f

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val tile = TextView(this)
        tile.text = opt.icon
        tile.textSize = 18f
        tile.gravity = Gravity.CENTER
        tile.background = shape(cTile, 12)
        tile.layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))

        val spacer = View(this)
        spacer.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)

        val info = text("i", 13f, cMuted, bold = true)
        info.gravity = Gravity.CENTER
        info.background = shape(Color.TRANSPARENT, 12, cStrokeOff, 1)
        val infoLp = LinearLayout.LayoutParams(dp(24), dp(24))
        infoLp.rightMargin = dp(6)
        info.layoutParams = infoLp
        info.setOnClickListener { showInfo(opt) }

        val sw = Switch(this)
        sw.isEnabled = false
        sw.showText = false
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(cCyan, Color.parseColor("#64748B")))
        sw.trackTintList = ColorStateList(states, intArrayOf(cCyanDark, Color.parseColor("#1E293B")))
        sw.setOnCheckedChangeListener { _, checked -> onToggle(opt, checked) }
        switches[opt.id] = sw

        top.addView(tile)
        top.addView(spacer)
        top.addView(info)
        top.addView(sw)
        c.addView(top)

        val title = text(opt.title, 15f, cText, bold = true)
        title.layoutParams = lp(10)
        c.addView(title)

        val sub = when {
            ok -> opt.short
            opt.unavailable != null -> "Indisponível: " + opt.unavailable
            else -> "Indisponível: precisa do API " + opt.minSdk
        }
        val subView = text(sub, 12f, if (ok) cMuted else cWarn)
        subView.maxLines = 2
        subView.ellipsize = TextUtils.TruncateAt.END
        subView.layoutParams = lp(2)
        c.addView(subView)
        if (ok) {
            val risk = text(if (opt.care) "⚠ Leia o i antes" else "✓ Seguro", 11f, if (opt.care) cWarn else cOk, bold = true)
            risk.layoutParams = lp(6)
            c.addView(risk)
        }
        return c
    }

    private val TAB_INTRO = mapOf(
        "Desempenho" to "Deixam apps e jogos mais rápidos e liberam memória. Toque no botão ao lado de cada cartão para ligar ou desligar.",
        "Tela" to "Taxa de atualização, animações, brilho e cores. Desligar volta ao valor que estava antes.",
        "Toque" to "Vibração, sons e resposta do toque. Para deixar o celular mais ágil e silencioso.",
        "Internet" to "Wi-Fi, Bluetooth e DNS privado. O DNS muda como seu celular acha os sites.",
        "Sistema" to "Energia e notificações. Toque no i de cada cartão para ver o que ele muda."
    )

    private fun buildHome(box: LinearLayout) {
        box.addView(sectionLabel("Resumo do aparelho"))
        val grid = newGrid()
        grid.addView(statCard("ram", "MEMÓRIA"))
        grid.addView(statCard("bat", "BATERIA"))
        grid.addView(statCard("disk", "ARMAZENAMENTO"))
        grid.addView(statCard("hz", "TELA"))
        grid.addView(statCard("act", "FUNÇÕES ATIVAS"))
        grid.addView(statCard("sup", "COMPATIBILIDADE"))
        grid.addView(statCard("dev", "MARCA"))
        grid.addView(statCard("and", "SISTEMA"))
        box.addView(grid)
        val refresh = btn("↻  Atualizar resumo", false) { updateStats() }
        box.addView(refresh)

        box.addView(sectionLabel("Funciona no seu celular?"))
        val comp = card()
        comp.addView(text(
            "Este app usa só ajustes do próprio Android, então serve para qualquer marca. " +
                "Cada função mostra se o seu aparelho suporta. Funções apagadas precisam de um Android mais novo ou de uma tela mais rápida.",
            12.5f, cMuted
        ))
        val c2 = text(
            "Algumas marcas (Xiaomi, Samsung, OPPO, vivo, Motorola) ignoram certos ajustes. " +
                "Quando isso acontece, o Registro mostra ✘ e nada é mudado. Nada aqui deixa o celular fora de ordem: tudo se desfaz em Restaurar tudo.",
            12.5f, cMuted
        )
        c2.layoutParams = lp(8)
        comp.addView(c2)
        box.addView(comp)

        box.addView(sectionLabel("Perfil"))
        val pa = card()
        val ps = text("", 15f, cText, bold = true)
        profileStatus.add(ps)
        pa.addView(ps)
        val pn = text("Um perfil liga várias funções de uma vez. Escolha o que combina com o seu momento.", 12.5f, cMuted)
        pn.layoutParams = lp(4)
        pa.addView(pn)
        pa.addView(btn("Escolher perfil", true) { selectTab("Perfis") })
        box.addView(pa)
    }

    private fun buildIntro(box: LinearLayout) {
        if (prefs.getBoolean("hide_intro", false)) return
        val c = card()
        c.addView(text("Comece por aqui", 16f, cText, bold = true))
        val steps = text(
            "1. Deixe o Shizuku ligado e toque em Conceder.\n" +
                "2. Abra a aba Perfis e escolha um: Performance, Bateria, Seguro ou Equilibrado.\n" +
                "3. Quer escolher uma por uma? Use as abas Desempenho, Tela, Toque, Internet e Sistema.\n" +
                "4. Não gostou? Toque em Restaurar tudo, na aba Ferramentas. Tudo volta ao que estava antes.",
            13f, cMuted
        )
        steps.layoutParams = lp(6)
        c.addView(steps)
        c.addView(btn("Entendi", false) {
            prefs.edit().putBoolean("hide_intro", true).apply()
            c.visibility = View.GONE
        })
        box.addView(c)
    }

    private fun profileCard(p: Profile): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = shape(cCard, 18, cStrokeOff, 1)
        c.layoutParams = lp(10)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val tile = TextView(this)
        tile.text = p.icon
        tile.textSize = 22f
        tile.gravity = Gravity.CENTER
        tile.background = shape(cTile, 14)
        tile.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        top.addView(tile)
        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        val nl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        nl.leftMargin = dp(12)
        names.layoutParams = nl
        names.addView(text(p.name, 18f, cText, bold = true))
        names.addView(text(p.badge, 12f, cCyan, bold = true))
        top.addView(names)
        c.addView(top)

        val d = text(p.note, 12.5f, cMuted)
        d.layoutParams = lp(10)
        c.addView(d)

        val opts = p.ids.mapNotNull { id -> OPTS.firstOrNull { it.id == id } }
        val ok = opts.filter { supported(it) }
        val list = text("Liga " + ok.size + " funções neste aparelho:", 12f, cText, bold = true)
        list.layoutParams = lp(10)
        c.addView(list)
        val names2 = ok.joinToString("  ·  ") { it.title }
        val ln = text(names2, 11.5f, cMuted)
        ln.layoutParams = lp(2)
        c.addView(ln)
        if (opts.size > ok.size) {
            val sk = text((opts.size - ok.size).toString() + " função(ões) deste perfil não existem neste aparelho e serão puladas.", 11.5f, cWarn)
            sk.layoutParams = lp(4)
            c.addView(sk)
        }
        if (p.freeMemory) {
            val fm = text("Também libera a memória na hora.", 11.5f, cMuted)
            fm.layoutParams = lp(4)
            c.addView(fm)
        }

        val b = actionBtn("Ativar", true) { applyProfile(p) }
        b.layoutParams = lp(12)
        profileButtons[p.name] = b
        c.addView(b)
        return c
    }

    private fun buildProfiles(box: LinearLayout) {
        box.addView(sectionLabel("Escolha um perfil"))
        val head = card()
        val st = text("", 15f, cText, bold = true)
        profileStatus.add(st)
        head.addView(st)
        val hn = text(
            "Ao trocar de perfil, o app desfaz o anterior e liga o novo. Cada função guarda o valor que estava antes, e Restaurar tudo devolve tudo.",
            12.5f, cMuted
        )
        hn.layoutParams = lp(4)
        head.addView(hn)
        head.addView(actionBtn("Desfazer o perfil (Restaurar tudo)", false) { bulk(false) })
        box.addView(head)
        for (p in PROFILES) box.addView(profileCard(p))
    }

    private fun buildGames(box: LinearLayout) {
        box.addView(sectionLabel("Seu jogo"))
        val game = card()
        game.addView(text("Escolha o jogo", 16f, cText, bold = true))
        val gd = text(
            "Escolha da lista ou digite o nome do pacote. O modo Game exige Android 12 ou mais novo.",
            12.5f,
            cMuted
        )
        gd.layoutParams = lp(4)
        game.addView(gd)

        pkgInput = EditText(this)
        pkgInput.hint = "com.exemplo.jogo"
        pkgInput.setHintTextColor(Color.parseColor("#4B6075"))
        pkgInput.setTextColor(cText)
        pkgInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        pkgInput.setSingleLine(true)
        pkgInput.setPadding(dp(14), dp(10), dp(14), dp(10))
        pkgInput.background = shape(cField, 12, cStrokeOff, 1)
        pkgInput.layoutParams = lp(12)
        pkgInput.setText(prefs.getString("last_pkg", "") ?: "")
        game.addView(pkgInput)

        gameLabel = text("", 12f, cMuted)
        gameLabel.layoutParams = lp(6)
        game.addView(gameLabel)

        game.addView(btn("Escolher da lista de apps", false) { pickApp() })
        box.addView(game)

        box.addView(sectionLabel("Ações do jogo"))
        val acts = card()
        acts.addView(actionBtn("🚀  Preparar e abrir o jogo", true) { prepareGame() })
        val pn = text("Libera memória, liga o modo desempenho (Android 12+) e abre o jogo.", 11.5f, cMuted)
        pn.layoutParams = lp(4)
        acts.addView(pn)
        acts.addView(actionBtn("Modo desempenho neste jogo", false) { gameAction("performance") })
        acts.addView(actionBtn("Voltar este jogo ao padrão", false) { gameAction("reset") })
        acts.addView(actionBtn("Ver modos disponíveis", false) { gameAction("list") })
        acts.addView(actionBtn("Limitar o FPS deste jogo", false) { pickFps() })
        val fn = text("Só funciona no Android 14 ou mais novo e em jogos que aceitam o modo Game.", 11.5f, cMuted)
        fn.layoutParams = lp(4)
        acts.addView(fn)
        acts.addView(actionBtn("Compilar este jogo (carrega mais rápido)", false) { compileGame() })
        val cn = text("Pode levar alguns minutos. Funciona em qualquer Android.", 11.5f, cMuted)
        cn.layoutParams = lp(4)
        acts.addView(cn)
        acts.addView(actionBtn("Parar o jogo", false) { stopGame() })
        box.addView(acts)
    }

    private fun buildTools(box: LinearLayout) {
        box.addView(sectionLabel("Memória e armazenamento"))
        val mem = card()
        mem.addView(actionBtn("Liberar memória agora", true) { runAction("Liberando memória", "am kill-all") })
        val mn = text("Fecha apps em segundo plano que o Android considera seguros de fechar.", 11.5f, cMuted)
        mn.layoutParams = lp(4)
        mem.addView(mn)
        mem.addView(actionBtn("Limpar cache dos apps", false) {
            runAction("Limpando cache dos apps", "pm trim-caches 999G")
        })
        mem.addView(actionBtn("Manutenção do sistema", false) {
            runAction("Rodando a manutenção do sistema", "am idle-maintenance")
        })
        box.addView(mem)

        box.addView(sectionLabel("Tela e avisos"))
        val scr = card()
        scr.addView(actionBtn("Tema escuro", false) {
            if (sdk >= 29) runAction("Ligando o tema escuro", "cmd uimode night yes") else toast("Precisa do Android 10 ou mais novo")
        })
        scr.addView(actionBtn("Tema claro", false) {
            if (sdk >= 29) runAction("Ligando o tema claro", "cmd uimode night no") else toast("Precisa do Android 10 ou mais novo")
        })
        scr.addView(actionBtn("Não perturbe: ligar", false) {
            runAction("Ligando o Não perturbe", "cmd notification set_dnd on")
        })
        scr.addView(actionBtn("Não perturbe: desligar", false) {
            runAction("Desligando o Não perturbe", "cmd notification set_dnd off")
        })
        scr.addView(actionBtn("Resetar resolução e densidade da tela", false) {
            runAction("Resetando resolução e densidade", "wm size reset; wm density reset")
        })
        val sn = text("O último botão é a saída de emergência se a tela ficar estranha por causa de outro app.", 11.5f, cMuted)
        sn.layoutParams = lp(4)
        scr.addView(sn)
        box.addView(scr)

        box.addView(sectionLabel("Rede"))
        val net = card()
        net.addView(actionBtn("Economia de dados: ligar", false) {
            runAction("Ligando a economia de dados", "cmd netpolicy set restrict-background true")
        })
        net.addView(actionBtn("Economia de dados: desligar", false) {
            runAction("Desligando a economia de dados", "cmd netpolicy set restrict-background false")
        })
        box.addView(net)

        box.addView(sectionLabel("Diagnóstico"))
        val diag = card()
        diag.addView(actionBtn("Ver status térmico", false) {
            runShow("Status térmico", "dumpsys thermalservice | head -n 40")
        })
        diag.addView(actionBtn("Ver detalhes da bateria", false) {
            runShow("Detalhes da bateria", "dumpsys battery")
        })
        val dg = text("Mostra o que o Android informa. Se vier vazio, o seu aparelho não tem esse dado.", 11.5f, cMuted)
        dg.layoutParams = lp(4)
        diag.addView(dg)
        box.addView(diag)

        box.addView(sectionLabel("Compilação dos apps"))
        val comp = card()
        comp.addView(actionBtn("Compilar apps (speed-profile, demora)", false) {
            runAction("Compilando apps, pode levar alguns minutos", "cmd package compile -m speed-profile -a")
        })
        comp.addView(actionBtn("Resetar compilação dos apps", false) {
            runAction("Resetando compilação", "cmd package compile --reset -a")
        })
        box.addView(comp)

        box.addView(sectionLabel("Limpeza de depuração"))
        val dbg = card()
        dbg.addView(actionBtn("Limpar ajustes de depuração", false) {
            runAction("Limpando ajustes de depuração", "for p in debug.hwui.renderer debug.hwui.overdraw debug.hwui.show_dirty_regions debug.hwui.show_layers_updates debug.hwui.profile debug.layout debug.egl.trace debug.egl.callstack debug.sf.showupdates; do setprop \$p ''; done")
        })
        val dn = text("Apaga ajustes gráficos de depuração que outros apps ou guias deixam ligados. Não mexe em dados nem em fotos.", 11.5f, cMuted)
        dn.layoutParams = lp(4)
        dbg.addView(dn)
        box.addView(dbg)

        box.addView(sectionLabel("Desfazer"))
        val undo = card()
        undo.addView(actionBtn("Restaurar tudo ao que estava antes", true) { bulk(false) })
        val un = text("Devolve só o que este app ligou, com o valor que estava antes.", 11.5f, cMuted)
        un.layoutParams = lp(4)
        undo.addView(un)
        box.addView(undo)

        box.addView(sectionLabel("Registro"))
        val reg = card()
        reg.addView(btn("Ver registro completo", false) { showLog() })
        reg.addView(btn("Copiar registro", false) { copyLog() })
        reg.addView(btn("Limpar registro", false) { clearLog() })
        box.addView(reg)

        box.addView(sectionLabel("Sobre"))
        val about = card()
        var ver = ""
        try {
            ver = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (t: Throwable) {
        }
        about.addView(text("TM Otimizador " + ver, 15f, cText, bold = true))
        val ab = text(
            "Android " + Build.VERSION.RELEASE + " (API " + sdk + ")\n" + Build.MANUFACTURER + " " + Build.MODEL +
                "\nOtimização via Shizuku, sem root.",
            12.5f,
            cMuted
        )
        ab.layoutParams = lp(4)
        about.addView(ab)
        box.addView(about)
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBgTop, cBgBottom))
        setContentView(root)

        // Cabeçalho
        val headRow = LinearLayout(this)
        headRow.orientation = LinearLayout.HORIZONTAL
        headRow.gravity = Gravity.CENTER_VERTICAL
        headRow.setPadding(dp(20), dp(26), dp(14), 0)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val sp = SpannableString("TM Otimizador")
        sp.setSpan(ForegroundColorSpan(cCyan), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val title = text("", 30f, cText, bold = true)
        title.text = sp
        head.addView(title)
        val sub = text("VIA SHIZUKU  |  SEM ROOT", 11f, cCyan, bold = true)
        sub.letterSpacing = 0.14f
        sub.layoutParams = lp(2)
        head.addView(sub)
        headRow.addView(head)
        val palBtn = TextView(this)
        palBtn.text = "🎨"
        palBtn.textSize = 20f
        palBtn.gravity = Gravity.CENTER
        palBtn.background = shape(cCard, 22, cStrokeOff, 1)
        palBtn.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        palBtn.setOnClickListener { pickPalette() }
        headRow.addView(palBtn)
        root.addView(headRow)

        // Status do Shizuku (uma linha)
        val statusBox = LinearLayout(this)
        statusBox.orientation = LinearLayout.HORIZONTAL
        statusBox.gravity = Gravity.CENTER_VERTICAL
        statusBox.setPadding(dp(14), dp(8), dp(8), dp(8))
        statusBox.background = shape(cCard, 16, cStrokeOff, 1)
        val sbLp = lp(14)
        sbLp.leftMargin = dp(18)
        sbLp.rightMargin = dp(18)
        statusBox.layoutParams = sbLp
        val dot = View(this)
        statusDot = GradientDrawable()
        statusDot.shape = GradientDrawable.OVAL
        statusDot.setColor(cWarn)
        dot.background = statusDot
        val dotLp = LinearLayout.LayoutParams(dp(10), dp(10))
        dotLp.rightMargin = dp(10)
        dot.layoutParams = dotLp
        status = text("Verificando…", 14f, cText, bold = true)
        status.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        permButton = btn("Conceder", true) { onPermClick() }
        permButton.minHeight = 0
        permButton.minimumHeight = 0
        permButton.setPadding(dp(16), dp(6), dp(16), dp(6))
        permButton.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38))
        permButton.visibility = View.GONE
        statusBox.addView(dot)
        statusBox.addView(status)
        statusBox.addView(permButton)
        root.addView(statusBox)

        // Busca
        searchInput = EditText(this)
        searchInput.hint = "🔍  Buscar função…"
        searchInput.setHintTextColor(Color.parseColor("#4B6075"))
        searchInput.setTextColor(cText)
        searchInput.textSize = 14f
        searchInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        searchInput.setSingleLine(true)
        searchInput.setPadding(dp(16), dp(10), dp(16), dp(10))
        searchInput.background = shape(cCard, 16, cStrokeOff, 1)
        val seLp = lp(12)
        seLp.leftMargin = dp(18)
        seLp.rightMargin = dp(18)
        searchInput.layoutParams = seLp
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        root.addView(searchInput)

        // Abas
        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        chipScroll.layoutParams = lp(12)
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        chipRow.setPadding(dp(18), 0, dp(10), 0)
        for (p in TABS) {
            val chip = text(p.second + "  " + p.first, 14f, cText, bold = true)
            chip.setPadding(dp(16), dp(10), dp(16), dp(10))
            val cl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            cl.rightMargin = dp(8)
            chip.layoutParams = cl
            val tabName = p.first
            chip.setOnClickListener { selectTab(tabName) }
            chipViews[tabName] = chip
            chipRow.addView(chip)
        }
        chipScroll.addView(chipRow)
        root.addView(chipScroll)

        // Conteúdo das abas
        contentScroll = ScrollView(this)
        contentScroll.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(13), dp(2), dp(13), dp(16))
        contentScroll.addView(content)
        root.addView(contentScroll)

        for (p in TABS) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            tabViews[p.first] = box
            content.addView(box)
            val intro = TAB_INTRO[p.first]
            if (intro != null) {
                val it2 = text(intro, 12.5f, cMuted)
                it2.setPadding(dp(8), dp(6), dp(8), 0)
                box.addView(it2)
            }
        }

        // Cartões das funções, por aba e seção
        var lastKey = ""
        var cur: Sec? = null
        for (opt in OPTS) {
            val key = opt.cat + "|" + opt.sec
            if (key != lastKey) {
                val label = sectionLabel(opt.sec)
                val grid = newGrid()
                val box = tabViews[opt.cat]
                box?.addView(label)
                box?.addView(grid)
                cur = Sec(opt.cat, label, grid)
                sections.add(cur)
                lastKey = key
            }
            val c = optCard(opt)
            c.layoutParams = cell()
            cur?.grid?.addView(c)
            cur?.cards?.add(Pair(opt, c))
        }

        // Abas de botões
        tabViews["Início"]?.let {
            buildIntro(it)
            buildHome(it)
        }
        tabViews["Perfis"]?.let { buildProfiles(it) }
        tabViews["Jogos"]?.let { buildGames(it) }
        tabViews["Ferramentas"]?.let { buildTools(it) }

        // Barra fixa de baixo
        val divider = View(this)
        divider.setBackgroundColor(cStrokeOff)
        divider.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        root.addView(divider)

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setBackgroundColor(Color.parseColor("#02060F"))
        bottom.setPadding(dp(16), dp(4), dp(16), dp(8))
        bottomStatus = text("Pronto  ·  toque aqui para ver o registro", 12f, cMuted)
        bottomStatus.gravity = Gravity.CENTER
        bottomStatus.maxLines = 1
        bottomStatus.ellipsize = TextUtils.TruncateAt.END
        bottomStatus.setPadding(0, dp(6), 0, dp(4))
        bottomStatus.setOnClickListener { showLog() }
        bottom.addView(bottomStatus)
        root.addView(bottom)

        for ((k, v) in chipViews) styleChip(v, k == currentTab)
        applyFilter()
        updateStats()
        refreshProfileUi()
    }
}
