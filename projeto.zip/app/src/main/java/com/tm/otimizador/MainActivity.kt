package com.tm.otimizador

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("opts", MODE_PRIVATE) }
    private val sdk = Build.VERSION.SDK_INT

    // Paleta: preto profundo com ciano neon, igual ao logo
    private val cBgTop = Color.parseColor("#000814")
    private val cBgBottom = Color.parseColor("#01030A")
    private val cCard = Color.parseColor("#09121F")
    private val cActive = Color.parseColor("#0B2B3B")
    private val cTile = Color.parseColor("#0F2230")
    private val cField = Color.parseColor("#050C16")
    private val cStrokeOff = Color.parseColor("#12303F")
    private val cCyan = Color.parseColor("#22D3EE")
    private val cCyanDark = Color.parseColor("#0E7490")
    private val cText = Color.parseColor("#E6F1FF")
    private val cMuted = Color.parseColor("#8AA0B8")
    private val cWarn = Color.parseColor("#FBBF24")
    private val cOk = Color.parseColor("#34D399")
    private val cInk = Color.parseColor("#001018")

    /** Uma seção de uma aba: título e grade de cartões. */
    private class Sec(val tab: String, val label: View, val grid: GridLayout) {
        val cards = ArrayList<Pair<Opt, View>>()
    }

    private val switches = LinkedHashMap<String, Switch>()
    private val cardBg = HashMap<String, GradientDrawable>()
    private val actionButtons = ArrayList<Button>()
    private val tabViews = LinkedHashMap<String, LinearLayout>()
    private val chipViews = LinkedHashMap<String, TextView>()
    private val sections = ArrayList<Sec>()
    private val optTabs = OPTS.map { it.cat }.toSet()

    private lateinit var contentScroll: ScrollView
    private lateinit var searchInput: EditText
    private lateinit var status: TextView
    private lateinit var statusDot: GradientDrawable
    private lateinit var permButton: Button
    private lateinit var bottomStatus: TextView
    private lateinit var pkgInput: EditText

    private var currentTab = TABS[0].first
    private var logText = ""
    private var suppress = false
    private var connected = false

    private val binderReceived = Shizuku.OnBinderReceivedListener { ui.post { refreshState() } }
    private val binderDead = Shizuku.OnBinderDeadListener { ui.post { refreshState() } }
    private val permResult = Shizuku.OnRequestPermissionResultListener { _, _ -> ui.post { refreshState() } }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBgTop
        window.navigationBarColor = cBgBottom
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permResult)
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permResult)
        worker.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- Shizuku

    private fun running(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (t: Throwable) {
            false
        }
    }

    private fun granted(): Boolean {
        if (!running()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (t: Throwable) {
            false
        }
    }

    private fun onPermClick() {
        if (!running()) {
            val intent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                startActivity(intent)
            } else {
                toast("Shizuku não está instalado. Instale e inicie o serviço.")
            }
            return
        }
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Permissão negada. Libere o TM Otimizador dentro do app Shizuku.")
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (t: Throwable) {
            toast("Erro ao pedir permissão: ${t.message}")
        }
    }

    /** Executa um comando de shell com a permissão do Shizuku. Retorna (código, saída). */
    private fun exec(cmd: String): Pair<Int, String> {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            Pair(code, out.trim())
        } catch (t: Throwable) {
            Pair(-1, t.cause?.message ?: t.message ?: t.toString())
        }
    }

    // ---------------------------------------------------------------- leitura / escrita dos ajustes

    private fun supported(opt: Opt): Boolean = sdk >= opt.minSdk

    /** Valor atual: texto, "" se a chave não existe, null se a leitura falhou. */
    private fun readTarget(t: Target): String? {
        val r = exec(Sh.read(t))
        if (r.first != 0) return null
        val v = r.second.trim()
        return if (v == "null" || v.isEmpty()) "" else v
    }

    private fun isActive(opt: Opt): Boolean {
        for (t in opt.targets) {
            val v = readTarget(t) ?: return false
            if (!Sh.same(v, t.on)) return false
        }
        return true
    }

    /** Ativa guardando o valor anterior e confere o resultado. Bloqueante. */
    private fun enableOpt(opt: Opt): Boolean {
        log("Ativando: " + opt.title + "…")

        // Funções do mesmo grupo não ficam ligadas juntas.
        val grp = opt.group
        if (grp != null) {
            for (other in OPTS) {
                if (other.id != opt.id && other.group == grp && supported(other) && isActive(other)) {
                    disableOpt(other)
                    ui.post { setSwitch(other.id, false) }
                }
            }
        }

        val cur = opt.targets.map { readTarget(it) }
        val already = opt.targets.indices.all { i ->
            val v = cur[i]
            v != null && Sh.same(v, opt.targets[i].on)
        }
        if (!already) {
            val ed = prefs.edit()
            ed.putBoolean("has_prev_" + opt.id, true)
            for (i in opt.targets.indices) {
                ed.putString("prev_" + opt.id + "_" + i, cur[i] ?: "")
            }
            ed.apply()
        }

        for (t in opt.targets) {
            val r = exec(Sh.write(t, t.on))
            if (r.first != 0) log("  ✘ " + t.key + ": " + r.second.take(200))
        }

        return if (isActive(opt)) {
            log("✔ ativado: " + opt.title)
            true
        } else {
            log("✘ o Android não aceitou: " + opt.title + ". Seu aparelho ou sua versão pode ignorar este ajuste.")
            false
        }
    }

    /** Desativa voltando ao valor que estava antes. Bloqueante. */
    private fun disableOpt(opt: Opt): Boolean {
        log("Desativando: " + opt.title + "…")
        val has = prefs.getBoolean("has_prev_" + opt.id, false)
        for (i in opt.targets.indices) {
            val t = opt.targets[i]
            if (has) {
                val prev = prefs.getString("prev_" + opt.id + "_" + i, "") ?: ""
                if (prev.isEmpty()) exec(Sh.clear(t)) else exec(Sh.write(t, prev))
            } else {
                val d = t.offDefault
                if (d != null) exec(Sh.write(t, d)) else exec(Sh.clear(t))
            }
        }
        val ed = prefs.edit()
        ed.remove("has_prev_" + opt.id)
        for (i in opt.targets.indices) ed.remove("prev_" + opt.id + "_" + i)
        ed.apply()

        return if (!isActive(opt)) {
            log("✔ desativado, valor anterior restaurado: " + opt.title)
            true
        } else {
            log("✘ não consegui desativar: " + opt.title + ". Tente de novo ou reinicie o aparelho.")
            false
        }
    }

    // ---------------------------------------------------------------- estado da tela

    private fun refreshState() {
        val run = running()
        connected = granted()
        when {
            !run -> {
                status.text = "Shizuku não está em execução"
                statusDot.setColor(cWarn)
                permButton.text = "Abrir Shizuku"
                permButton.visibility = View.VISIBLE
            }
            !connected -> {
                status.text = "Shizuku ativo, falta a permissão"
                statusDot.setColor(cWarn)
                permButton.text = "Conceder"
                permButton.visibility = View.VISIBLE
            }
            else -> {
                status.text = "Shizuku conectado"
                statusDot.setColor(cOk)
                permButton.visibility = View.GONE
            }
        }
        setBusy(false)
        if (connected) syncStates()
    }

    /** Lê o estado real de cada função no aparelho e ajusta as chaves. */
    private fun syncStates() {
        worker.execute {
            for (opt in OPTS) {
                if (!supported(opt)) continue
                val state = isActive(opt)
                ui.post { setSwitch(opt.id, state) }
            }
        }
    }

    private fun setSwitch(id: String, value: Boolean) {
        val s = switches[id] ?: return
        suppress = true
        s.isChecked = value
        suppress = false
        val bg = cardBg[id] ?: return
        bg.setColor(if (value) cActive else cCard)
        bg.setStroke(dp(if (value) 2 else 1), if (value) cCyan else cStrokeOff)
    }

    private fun setBusy(busy: Boolean) {
        for (opt in OPTS) {
            switches[opt.id]?.isEnabled = !busy && connected && supported(opt)
        }
        for (b in actionButtons) {
            b.isEnabled = !busy && connected
            b.alpha = if (b.isEnabled) 1f else 0.4f
        }
    }

    // ---------------------------------------------------------------- ações

    private fun onToggle(opt: Opt, checked: Boolean) {
        if (suppress) return
        if (!connected) {
            setSwitch(opt.id, !checked)
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            if (checked) enableOpt(opt) else disableOpt(opt)
            val real = isActive(opt)
            ui.post {
                setSwitch(opt.id, real)
                setBusy(false)
            }
        }
    }

    private fun bulk(enable: Boolean) {
        if (!connected) {
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            for (opt in OPTS) {
                if (!supported(opt)) continue
                if (enable) {
                    if (!opt.inBulk) continue
                    enableOpt(opt)
                } else {
                    // Restaurar só mexe no que este app ligou e guardou o valor anterior.
                    if (!prefs.getBoolean("has_prev_" + opt.id, false)) continue
                    disableOpt(opt)
                }
                val real = isActive(opt)
                ui.post { setSwitch(opt.id, real) }
            }
            ui.post { setBusy(false) }
        }
    }

    private fun runAction(label: String, cmd: String) {
        if (!connected) {
            toast("Conecte o Shizuku primeiro")
            return
        }
        setBusy(true)
        worker.execute {
            log("$label…")
            val r = exec(cmd)
            if (r.first == 0) log("✔ concluído" + snip(r.second)) else log("✘ erro (" + r.first + "): " + r.second.take(300))
            ui.post { setBusy(false) }
        }
    }

    /** Modo Game de um jogo. O nome do pacote é validado antes de ir para o shell. */
    private fun gameAction(performance: Boolean) {
        val pkg = pkgInput.text.toString().trim()
        if (!Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$").matches(pkg)) {
            toast("Digite um nome de pacote válido, como com.exemplo.jogo")
            return
        }
        if (sdk < 31) {
            toast("O modo Game exige Android 12 ou mais novo")
            return
        }
        if (performance) {
            runAction("Modo desempenho em $pkg", "cmd game mode performance $pkg")
        } else {
            runAction("Voltando $pkg ao padrão", "cmd game reset $pkg")
        }
    }

    private fun snip(s: String): String = if (s.isBlank()) "" else ": " + s.take(300)

    private fun log(msg: String) {
        ui.post {
            logText = (logText + msg + "\n").takeLast(6000)
            bottomStatus.text = "▲  " + msg.trim()
        }
    }

    private fun showLog() {
        AlertDialog.Builder(this)
            .setTitle("Registro")
            .setMessage(if (logText.isBlank()) "Nada por aqui ainda." else logText)
            .setPositiveButton("Fechar", null)
            .show()
    }

    private fun showInfo(opt: Opt) {
        val cmds = opt.targets.joinToString("\n") { "• " + Sh.write(it, it.on) }
        var msg = opt.desc + "\n\nO que o app muda:\n" + cmds
        if (!supported(opt)) {
            msg += "\n\nSeu Android é o API " + sdk + ". Esta função precisa do API " + opt.minSdk + "."
        }
        AlertDialog.Builder(this)
            .setTitle(opt.title)
            .setMessage(msg)
            .setPositiveButton("Entendi", null)
            .show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- abas e busca

    private fun selectTab(tab: String) {
        currentTab = tab
        for ((k, v) in chipViews) styleChip(v, k == tab)
        searchInput.setText("")
        applyFilter()
        contentScroll.scrollTo(0, 0)
    }

    private fun styleChip(t: TextView, selected: Boolean) {
        if (selected) {
            t.setTextColor(cInk)
            t.background = shape(cCyan, 22)
        } else {
            t.setTextColor(cText)
            t.background = shape(cCard, 22, cStrokeOff, 1)
        }
    }

    /** Mostra só a aba escolhida; com busca, mostra os cartões que combinam em todas as abas de chaves. */
    private fun applyFilter() {
        val q = searchInput.text.toString().trim().lowercase()
        val searching = q.isNotEmpty()
        for ((tab, box) in tabViews) {
            val show = if (searching) optTabs.contains(tab) else tab == currentTab
            box.visibility = if (show) View.VISIBLE else View.GONE
        }
        for (s in sections) {
            var any = false
            for (p in s.cards) {
                val o = p.first
                val match = !searching ||
                    o.title.lowercase().contains(q) ||
                    o.short.lowercase().contains(q) ||
                    o.desc.lowercase().contains(q)
                p.second.visibility = if (match) View.VISIBLE else View.GONE
                if (match) any = true
            }
            val vis = if (any) View.VISIBLE else View.GONE
            s.label.visibility = vis
            s.grid.visibility = vis
        }
    }

    // ---------------------------------------------------------------- interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, radiusDp: Int, strokeColor: Int? = null, strokeDp: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != null) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(top)
        return p
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = shape(cCard, 18, cStrokeOff, 1)
        c.layoutParams = lp(10)
        return c
    }

    /** Botão cheio (principal) ou só contorno (secundário). */
    private fun btn(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.stateListAnimator = null
        b.textSize = 14f
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.minHeight = dp(48)
        if (primary) {
            b.setTextColor(cInk)
            b.background = shape(cCyan, 14)
        } else {
            b.setTextColor(cCyan)
            b.background = shape(Color.TRANSPARENT, 14, cCyanDark, 1)
        }
        b.setOnClickListener { onClick() }
        b.layoutParams = lp(10)
        return b
    }

    private fun actionBtn(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = btn(label, primary, onClick)
        b.isEnabled = false
        b.alpha = 0.4f
        actionButtons.add(b)
        return b
    }

    /** Célula da grade de 2 colunas. */
    private fun cell(): GridLayout.LayoutParams {
        val p = GridLayout.LayoutParams(
            GridLayout.spec(GridLayout.UNDEFINED),
            GridLayout.spec(GridLayout.UNDEFINED, 1f)
        )
        p.width = 0
        p.setMargins(dp(5), dp(5), dp(5), dp(5))
        p.setGravity(Gravity.FILL)
        return p
    }

    private fun sectionLabel(title: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = lp(18)
        row.setPadding(dp(6), 0, 0, dp(4))
        val bar = View(this)
        bar.background = shape(cCyan, 2)
        val barLp = LinearLayout.LayoutParams(dp(3), dp(14))
        barLp.rightMargin = dp(10)
        bar.layoutParams = barLp
        val t = text(title.uppercase(), 12f, cCyan, bold = true)
        t.letterSpacing = 0.16f
        row.addView(bar)
        row.addView(t)
        return row
    }

    private fun newGrid(): GridLayout {
        val g = GridLayout(this)
        g.columnCount = 2
        g.layoutParams = lp(0)
        return g
    }

    private fun optCard(opt: Opt): View {
        val ok = supported(opt)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), dp(12), dp(12), dp(12))
        val bg = shape(cCard, 18, cStrokeOff, 1)
        c.background = bg
        cardBg[opt.id] = bg
        if (!ok) c.alpha = 0.55f

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val tile = TextView(this)
        tile.text = opt.icon
        tile.textSize = 18f
        tile.gravity = Gravity.CENTER
        tile.background = shape(cTile, 12)
        tile.layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))

        val spacer = View(this)
        spacer.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)

        val info = text("i", 13f, cMuted, bold = true)
        info.gravity = Gravity.CENTER
        info.background = shape(Color.TRANSPARENT, 12, cStrokeOff, 1)
        val infoLp = LinearLayout.LayoutParams(dp(24), dp(24))
        infoLp.rightMargin = dp(6)
        info.layoutParams = infoLp
        info.setOnClickListener { showInfo(opt) }

        val sw = Switch(this)
        sw.isEnabled = false
        sw.showText = false
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(cCyan, Color.parseColor("#64748B")))
        sw.trackTintList = ColorStateList(states, intArrayOf(cCyanDark, Color.parseColor("#1E293B")))
        sw.setOnCheckedChangeListener { _, checked -> onToggle(opt, checked) }
        switches[opt.id] = sw

        top.addView(tile)
        top.addView(spacer)
        top.addView(info)
        top.addView(sw)
        c.addView(top)

        val title = text(opt.title, 15f, cText, bold = true)
        title.layoutParams = lp(10)
        c.addView(title)

        val sub = if (ok) opt.short else "Indisponível: precisa do API " + opt.minSdk
        val subView = text(sub, 12f, if (ok) cMuted else cWarn)
        subView.maxLines = 2
        subView.ellipsize = TextUtils.TruncateAt.END
        subView.layoutParams = lp(2)
        c.addView(subView)
        return c
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBgTop, cBgBottom))
        setContentView(root)

        // Cabeçalho
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(20), dp(26), dp(20), 0)
        val sp = SpannableString("TM Otimizador")
        sp.setSpan(ForegroundColorSpan(cCyan), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val title = text("", 30f, cText, bold = true)
        title.text = sp
        head.addView(title)
        val sub = text("AJUSTES  ·  VIA SHIZUKU  |  SEM ROOT", 11f, cCyan, bold = true)
        sub.letterSpacing = 0.14f
        sub.layoutParams = lp(2)
        head.addView(sub)
        root.addView(head)

        // Status do Shizuku (uma linha)
        val statusBox = LinearLayout(this)
        statusBox.orientation = LinearLayout.HORIZONTAL
        statusBox.gravity = Gravity.CENTER_VERTICAL
        statusBox.setPadding(dp(14), dp(8), dp(8), dp(8))
        statusBox.background = shape(cCard, 16, cStrokeOff, 1)
        val sbLp = lp(14)
        sbLp.leftMargin = dp(18)
        sbLp.rightMargin = dp(18)
        statusBox.layoutParams = sbLp
        val dot = View(this)
        statusDot = GradientDrawable()
        statusDot.shape = GradientDrawable.OVAL
        statusDot.setColor(cWarn)
        dot.background = statusDot
        val dotLp = LinearLayout.LayoutParams(dp(10), dp(10))
        dotLp.rightMargin = dp(10)
        dot.layoutParams = dotLp
        status = text("Verificando…", 14f, cText, bold = true)
        status.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        permButton = btn("Conceder", true) { onPermClick() }
        permButton.minHeight = 0
        permButton.minimumHeight = 0
        permButton.setPadding(dp(16), dp(6), dp(16), dp(6))
        permButton.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38))
        permButton.visibility = View.GONE
        statusBox.addView(dot)
        statusBox.addView(status)
        statusBox.addView(permButton)
        root.addView(statusBox)

        // Busca
        searchInput = EditText(this)
        searchInput.hint = "🔍  Buscar função…"
        searchInput.setHintTextColor(Color.parseColor("#4B6075"))
        searchInput.setTextColor(cText)
        searchInput.textSize = 14f
        searchInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        searchInput.setSingleLine(true)
        searchInput.setPadding(dp(16), dp(10), dp(16), dp(10))
        searchInput.background = shape(cCard, 16, cStrokeOff, 1)
        val seLp = lp(12)
        seLp.leftMargin = dp(18)
        seLp.rightMargin = dp(18)
        searchInput.layoutParams = seLp
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        root.addView(searchInput)

        // Abas
        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        chipScroll.layoutParams = lp(12)
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        chipRow.setPadding(dp(18), 0, dp(10), 0)
        for (p in TABS) {
            val chip = text(p.second + "  " + p.first, 14f, cText, bold = true)
            chip.setPadding(dp(16), dp(10), dp(16), dp(10))
            val cl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            cl.rightMargin = dp(8)
            chip.layoutParams = cl
            val tabName = p.first
            chip.setOnClickListener { selectTab(tabName) }
            chipViews[tabName] = chip
            chipRow.addView(chip)
        }
        chipScroll.addView(chipRow)
        root.addView(chipScroll)

        // Conteúdo das abas
        contentScroll = ScrollView(this)
        contentScroll.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(13), dp(2), dp(13), dp(16))
        contentScroll.addView(content)
        root.addView(contentScroll)

        for (p in TABS) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            tabViews[p.first] = box
            content.addView(box)
        }

        // Cartões das funções, por aba e seção
        var lastKey = ""
        var cur: Sec? = null
        for (opt in OPTS) {
            val key = opt.cat + "|" + opt.sec
            if (key != lastKey) {
                val label = sectionLabel(opt.sec)
                val grid = newGrid()
                val box = tabViews[opt.cat]
                box?.addView(label)
                box?.addView(grid)
                cur = Sec(opt.cat, label, grid)
                sections.add(cur)
                lastKey = key
            }
            val c = optCard(opt)
            c.layoutParams = cell()
            cur?.grid?.addView(c)
            cur?.cards?.add(Pair(opt, c))
        }

        // Aba Jogos
        val gameBox = tabViews["Jogos"]
        if (gameBox != null) {
            gameBox.addView(sectionLabel("Modo Game"))
            val game = card()
            game.addView(text("Prioridade de desempenho", 16f, cText, bold = true))
            val gd = text(
                "Pede ao Android (12 ou mais novo) para priorizar o desempenho de um jogo. Digite o nome do pacote do jogo.",
                12.5f,
                cMuted
            )
            gd.layoutParams = lp(4)
            game.addView(gd)
            pkgInput = EditText(this)
            pkgInput.hint = "com.exemplo.jogo"
            pkgInput.setHintTextColor(Color.parseColor("#4B6075"))
            pkgInput.setTextColor(cText)
            pkgInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            pkgInput.setSingleLine(true)
            pkgInput.setPadding(dp(14), dp(10), dp(14), dp(10))
            pkgInput.background = shape(cField, 12, cStrokeOff, 1)
            pkgInput.layoutParams = lp(12)
            game.addView(pkgInput)
            game.addView(actionBtn("Modo desempenho neste jogo", true) { gameAction(true) })
            game.addView(actionBtn("Voltar este jogo ao padrão", false) { gameAction(false) })
            gameBox.addView(game)
        }

        // Aba Ferramentas
        val toolsBox = tabViews["Ferramentas"]
        if (toolsBox != null) {
            toolsBox.addView(sectionLabel("Ações"))
            val tools = card()
            tools.addView(actionBtn("Restaurar tudo ao que estava antes", true) { bulk(false) })
            tools.addView(actionBtn("Limpar cache dos apps", false) {
                runAction("Limpando cache dos apps", "pm trim-caches 999G")
            })
            tools.addView(actionBtn("Compilar apps (speed-profile, demora)", false) {
                runAction("Compilando apps, pode levar alguns minutos", "cmd package compile -m speed-profile -a")
            })
            tools.addView(actionBtn("Resetar compilação dos apps", false) {
                runAction("Resetando compilação", "cmd package compile --reset -a")
            })
            val reg = btn("Ver registro completo", false) { showLog() }
            tools.addView(reg)
            toolsBox.addView(tools)

            toolsBox.addView(sectionLabel("Sobre"))
            val about = card()
            var ver = ""
            try {
                ver = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
            } catch (t: Throwable) {
            }
            about.addView(text("TM Otimizador " + ver, 15f, cText, bold = true))
            val ab = text(
                "Android " + Build.VERSION.RELEASE + " (API " + sdk + ")\n" + Build.MANUFACTURER + " " + Build.MODEL,
                12.5f,
                cMuted
            )
            ab.layoutParams = lp(4)
            about.addView(ab)
            toolsBox.addView(about)
        }

        // Barra fixa de baixo
        val divider = View(this)
        divider.setBackgroundColor(cStrokeOff)
        divider.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        root.addView(divider)

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setBackgroundColor(Color.parseColor("#02060F"))
        bottom.setPadding(dp(16), dp(6), dp(16), dp(10))
        val cta = actionBtn("ATIVAR PACOTE SEGURO", true) { bulk(true) }
        cta.textSize = 15f
        cta.letterSpacing = 0.08f
        cta.layoutParams = lp(4)
        bottom.addView(cta)
        bottomStatus = text("Pronto  ·  nada aplicado", 12f, cMuted)
        bottomStatus.gravity = Gravity.CENTER
        bottomStatus.maxLines = 1
        bottomStatus.ellipsize = TextUtils.TruncateAt.END
        bottomStatus.setPadding(0, dp(8), 0, dp(2))
        bottomStatus.setOnClickListener { showLog() }
        bottom.addView(bottomStatus)
        root.addView(bottom)

        for ((k, v) in chipViews) styleChip(v, k == currentTab)
        applyFilter()
    }
}
